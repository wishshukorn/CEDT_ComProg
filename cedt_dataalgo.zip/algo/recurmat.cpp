// #include<iostream>
// #include<vector>
// using namespace std;

// void recur(vector<vector<int>> &v, int a, int b,int top,int bottom,int left,int right)
// {
    
//     if(a==0){
//         // cout << b << " ";
//         v[top][left] = b;
//         return;
//     }
//     int mid_row = (top + bottom) / 2;
//     int mid_col = (left + right) / 2;

//     // เรียกฟังก์ชัน recur สำหรับ 4 ส่วนของเมทริกซ์
//     recur(v, a-1, b, top, mid_row, left, mid_col);           // H(a-1, b)
//     recur(v, a-1, b-1, top, mid_row, mid_col, right);       // H(a-1, b-1)
//     recur(v, a-1, b+1, mid_row, bottom, left, mid_col);     // H(a-1, b+1)
//     recur(v, a-1, b, mid_row, bottom, mid_col, right);
//     // recur(v, a-1, b, top+1, bottom/2, left+1, right/2);
//     // recur(v, a-1, b, top, bottom, left+1, right);
// }

// // void recurmat(int a, int b)
// // {
// //     if(a==0){
// //         cout << b << " ";
// //     }
// //     recurmat(a-1, b);
// //     recurmat(a-1, b-1);
// //     cout << endl;
// //     recurmat(a-1, b+1);
// //     recurmat(a-1, b);
// // }
// int main(){
//     int a, b;
//     cin >> a >> b;
//     vector<vector<int>> v;
//     // if(a==0){
//     //     cout << b;
//     // }
//     // recurmat(a, b);
//     recur(v ,a ,b ,0 ,1 << a ,0 ,1 << a);
//     for(int i=0;i<(1<<a);i++){
//         for(int j=0;j<(1<<a);j++){
//             cout << v[i][j];
//         }
//         cout << endl;

//     }
// }

#include <iostream>
#include <vector>
using namespace std;

// ฟังก์ชันที่ใช้สร้างเมทริกซ์ H(a, b)
void recur(vector<vector<int>>& v, int a, int b, int top, int bottom, int left, int right) {
    // กรณีฐาน (Base Case)
    if (a == 0) {
        v[top][left] = b;
        return;
    }

    // ขนาดของเมทริกซ์ในระดับนี้
    int mid_row = (top + bottom) / 2; //midy
    int mid_col = (left + right) / 2; //midx

    // เรียกฟังก์ชัน recur สำหรับ 4 ส่วนของเมทริกซ์
    recur(v, a-1, b, top, mid_row, left, mid_col);           // H(a-1, b)
    recur(v, a-1, b-1, top, mid_row, mid_col, right);       // H(a-1, b-1)
    recur(v, a-1, b+1, mid_row, bottom, left, mid_col);     // H(a-1, b+1)
    recur(v, a-1, b, mid_row, bottom, mid_col, right);      // H(a-1, b)
}

int main() {
    int a, b;
    cin >> a >> b;
    
    // ขนาดของเมทริกซ์ H(a, b) คือ 2^a x 2^a
    int size = 1 << a;  // 2^a
    vector<vector<int>> matrix(size, vector<int>(size));
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }

    // เรียกฟังก์ชัน recur สำหรับสร้างเมทริกซ์ H(a, b)
    recur(matrix, a, b, 0, size, 0, size);

    // แสดงผลเมทริกซ์
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
