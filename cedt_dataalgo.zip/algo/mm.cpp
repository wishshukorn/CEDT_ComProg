#include<iostream>
#include<vector>
using namespace std;

long long n;
int k;
vector<int> a(4, 0);

vector<int> mul(vector<int>&a, vector<int>&b){
    return {((a[0]%k * b[0]%k) + (a[1]%k * b[2]%k))%k, ((a[0]%k * b[1]%k) + (a[1]%k * b[3]%k))%k, 
    ((a[2]%k * b[0]%k) + (a[3]%k * b[2]%k))%k, ((a[2]%k * b[1]%k) + (a[3]%k * b[3])%k)%k};
}

vector<int> solve(long long num){
    if(num == 1){
        return a;
    }
    vector<int> t = solve(num >> 1);
    if(num%2 == 1){
        vector<int> tt = mul(t, t);
        return mul(tt, a);
    }else{
        return mul(t, t);
    }
}

int main(){
    
    cin >> n >> k >> a[0] >> a[1] >> a[2] >> a[3];
    // vector<vector<int>> b(4, vector<int>(n/2+1, 0));
    // b[0] = mul(a, a);
    // for(long long i=1;i<n/2;i++){
    //     b[i] = mul(b[i-1], b[i-1]);
    // }
    // if(n%2!=0){
    //     b[n/2-1] = mul(b[n/2-2], a);
    // }
    // for(int i=0;i<4;i++){
    //     cout << b[n/2-1][i] << " ";
    // }
    for(auto &x : solve(n)){
        cout << x << " ";
    }
    
    
}