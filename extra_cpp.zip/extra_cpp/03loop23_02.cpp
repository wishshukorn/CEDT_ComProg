#include<iostream>
using namespace std;
int main(){
    string a;
    int num;
    cin >> a >> num;
    if(num>1 && num<1000){
        return 0;
    }
    char fir = a[0];
    int cnt = 0;
    for(int i=0;i<a.length();i++){
        while(fir == a[i]){
            cnt++;
            i++;
        }
        if(cnt<num){
            for(int j=0;j<cnt;j++){
                cout << fir;
            }
        }
        fir = a[i];
        cnt = 1;
    }
}