#include<iostream>
#include<string>
using namespace std;
namespace CEDT{
    template <typename T1, typename T2>
    class pair{
        public:
        T1 first;
        T2 second;
    };
}

int main(){
    CEDT::pair<int, string> p1, p2;
    p1.first = 20;
    p1.second = "somchai";
    CEDT::pair<int, string> a(p1);
    p2 = p1;
    cout << p1.first << ", " << p1.second << endl << p2.first << ", " << p2.second << endl << a.first << ", " << a.second << endl;
    // if(p1==p2){}
    return 0;
}