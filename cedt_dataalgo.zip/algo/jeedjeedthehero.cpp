#include<iostream>
#include<vector>
using namespace std;

int cnt = 0;
int ans = 0;
int n, m;

int jeed(vector<vector<int>> a, int cnt, int ans){
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            if(a[i][j]==2){
                ans = ans + cnt;
            }
        }
    }

}

int main(){
    
    cin >> n >> m;
    // int a[n][m];
    vector<vector<int>> a(n, vector<int>(m));
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin >> a[i][j];
        }
    }
}