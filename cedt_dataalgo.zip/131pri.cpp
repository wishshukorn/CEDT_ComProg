#include<iostream>
#include<queue>
#include<vector>
#include<algorithm>
using namespace std;

iterator max_element(iterator first, iterator last){
    if(first == last){
        return last;
    }
    iterator largest = first;
    ++first;
    for(;first != last; ++first){
        if(*largest < *first){
            largest = first;
        }
    }
    return largest;
}

namespace CP{
    template <typename T>
    class priority_pueue{
        protected:
            std::vector<T> v;
        public:
            bool empty(){
                return v.empty();
            }
            bool size(){
                return v.size();
            }
            void push(const T & e){
                v.push_back(e);
            }
            T & top(){
                return v[v.size()-1];
            }
            void pop(){
                v.erase(v.end()-1);
            }
            void push(const T & e){
                v.push_back(e);
                sort(v.begin(), v.end());
            }
            void push(const T & e){
                auto it = v.begin();
                while(it < v.end() && *it <= e){
                    it++;
                }
                v.insert(it, e);
            }
            void push(const T & e){
                v.insert(std::upper_bound(v.begin(), v.end(), e), e)
            }
            T top(){
                return *std::max_element(v.begin(), v.end());
            }
            void pop(){
                v.erase(std::max_element(v.begin(), v.end()));
            }
    }
}

int main(){
    priority_queue<int> pq;
    pq.push(4);
    pq.push(20);
    pq.push(3);
    while(pq.empty() == false){
        cout << pq.top() << endl;
        pq.pop();
    }
}