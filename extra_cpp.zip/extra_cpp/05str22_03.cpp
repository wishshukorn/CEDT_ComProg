#include<iostream>
#include<string>
#include<math.h>
#include<algorithm>

using namespace std;

int main() {
    string text1,text2;
    cin>>text1>>text2;
    
    int len1 = text1.length();
    int len2 = text2.length();
    int mx = max(len1, len2);
  
    int x[mx];
    int y[mx];
    
    for (int i=0; i<mx;i++) {
        int sum=0;
        for (int j=0; j<len1;j++) {
            if (text1[j] == text2[i+j]) {
                sum++;
            }
        }
        x[i] = sum;
    }
    for (int i=0; i<mx; i++) {
        int sum=0;
        for (int j=0; j<len2;j++) {
            if (text2[j] == text1[i+j]) {
                sum++;
            }
        }
        y[i] = sum;
    }
    int *xmx = max_element(x, x + mx);
    int *ymx = max_element(y, y + mx);
    int xymx = max(*xmx, *ymx);
    
    for (int i=0;i<mx;i++) {
        if (xymx == x[i]){
            for (int j=0;j<i;j++) {
                cout << "-";
            }
            cout<<text1<<"\n";
            cout<<text2<<"\n";
            cout<<x[i];
            break;
        } 
        if (xymx == y[i]){
            cout << text1 << "\n";
            for (int j=0;j<i;j++) {
                cout<<"-";
            }
            cout<<text2 <<"\n";
            cout<<y[i];
            break;
        }
    }
   
    return 0;
}