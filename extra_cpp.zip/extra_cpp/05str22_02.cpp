#include<iostream>
#include<cmath>
using namespace std;
int main(){
    string a, b;
    cin >> a >> b;
    int num = max(b.length(), a.length());
    int minn = min(b.length(), a.length());
    int cnt = 0;
    int maxx = -2e9;
    int maxx_index = 0;
    int maxx_array;

    for(int i=0;i<abs(num);i++){
        cnt = 0;
        for(int j=0;j<minn;j++){
            if(a[j]==b[j+i]){
                cnt++;
            }
        }
        // minn--;
        if(cnt > maxx){
            maxx = cnt;
            maxx_index = i;
            maxx_array = 1;
        }
        cnt=0;
        for(int j=0;j<minn;j++){
            if(a[j+i]==b[j]){
                cnt++;
            }
        }
        if(cnt > maxx){
            maxx = cnt;
            maxx_index = i;
            maxx_array = 2;
        }
    }
    // cout << maxx << endl << maxx_index << endl;
    if(maxx_array==1){
        for(int i=0;i<maxx_index;i++){
            cout << "-";
        }
        cout << a << endl << b << endl << maxx;
    }else if(maxx_array==2){
        cout << a << endl;
        for(int i=0;i<maxx_index;i++){
            cout << "-";
        }
        cout << b << endl << maxx;
    }
}