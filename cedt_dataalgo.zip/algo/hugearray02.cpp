#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main(){
    std::ios_base::sync_with_stdio(0); cin.tie(0);
    int n, q;
    int a, b;
    vector<int> v;
    cin >> n >> q;
    for(int i=0;i<n;i++){
        cin >> a >> b;
        // while(b--){
        //     v.push_back(a);
        // }
    }
    sort(v.begin(), v.end());
    for(int i=0;i<q;i++){
        cin >> a;
        cout << v[a-1] << endl;
    }
    
}