#include<iostream>
#include<map>
#include<set>
using namespace std;

// bool findValue(map<int, string> m, string a){
//     bool ans = false;
//     for(auto& i:m){
//         if(i.second == a){
//             ans = true;
//             return ans;
//         }
//     }
//     return ans;
// }

int main(){
    std::ios_base::sync_with_stdio(false); std::cin.tie(0);

    int n, k;
    string a;
    map<string, int> m;
    multimap<int, string> m1;
    
    // set<pair<int, string>> s;

    cin >> n >> k;
    while(n--){
        cin >> a;
        m[a]++;
    }
    for(auto& i:m){
        // m1[i.second] = i.first;
        m1.insert(pair<int, string>(i.second, i.first));
    }
    // for(auto& i: m1){
    //     cout << i.first << " " << i.second << endl;
    // }
    // int sto = 0;
    auto itr = m1.end();
    // itr--;
    if(k>m1.size()){
        k=m1.size();
    }
    while(k--){
        itr--;
    }
    // itr--;
    // itr++;
    cout << (*itr).first;
}