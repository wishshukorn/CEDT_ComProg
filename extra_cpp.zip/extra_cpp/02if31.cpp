#include<iostream>
#include<cmath>
using namespace std;
int main(){
    int ds, ms, ys;
    int de, me, ye;
    int red=0, blue=0, black=0, sum=0;
    cin >> ds >> ms >> ys >> de >> me >> ye;
    ys=ys-543;
    ye=ye-543;

    for(int i=ms;i<=12;i++){
        if(i==4||i==6||i==9||i==11){
            red = red - 1;
        }
        if(i==2&&ys%4==0&&(ys%100!=0||ys%400==0)){
            red = red - 2;
        }else if(i==2){
            red = red - 3;
        }
        red = red + 31;
    }
    red = red - ds + 1;
    // cout << red << endl;

    for(int i=1;i<me;i++){
        if(i==4||i==6||i==9||i==11){
            blue = blue - 1;
        }
        if(i==2&&ye%4==0&&(ye%100!=0||ye%400==0)){
            blue = blue - 2;
        }else if(i==2){
            blue = blue - 3;
        }
        blue = blue + 31;
    }
    blue = blue + de - 1;
    // cout << blue << endl;

    black = black + (365*(ye-ys-1));
    // cout << black << endl;

    sum = red + blue + black;
    cout << sum << ' ' << round((sin((2*M_PI*sum)/23))*100.0)/100.0
    << ' ' << round((sin((2*M_PI*sum)/28))*100.0)/100.0
    << ' ' << round((sin((2*M_PI*sum)/33))*100.0)/100.0;

    return 0;
}