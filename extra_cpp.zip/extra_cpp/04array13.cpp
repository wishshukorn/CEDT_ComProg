#include<iostream>
using namespace std;
int main(){
    int num;
    cin >> num;
    int a[num], peak=0;
    for(int i=0;i<num;i++){
        cin >> a[i];
    }
    for(int i=1;i<num-1;i++){
        if(a[i]>a[i-1]&&a[i]>a[i+1]){
            peak++;
        }
    }
    cout << peak;
}