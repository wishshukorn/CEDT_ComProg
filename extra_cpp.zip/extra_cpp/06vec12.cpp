#include<iostream>
#include<vector>
using namespace std;
int main(){
    int n;
    vector<int> a;
    cin >> n;
    a.push_back(n);
    while(n!=1){
        if(n%2==0){
            n = n/2;
        }else{
            n = 3*n + 1;
        }
        a.push_back(n);
    }
    if(a.size()>15){
        for(auto i=a.end()-15;i!=a.end();i++){
            cout << *i;
            if(i!=a.end()-1){
                cout << "->";
            }
        }
    }else{
        for(auto i=a.begin();i!=a.end();i++){
            cout << *i;
            if(i!=a.end()-1){
                cout << "->";
            }
        }
    }
    return 0;
}