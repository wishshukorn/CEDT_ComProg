// public class Jeng{
//     public static void main(String[] a){
//         main(args);
//     }
// }

public class StackFrame{
    public static void main(String[] args){
        a(3, 2);
        b(5);
    }
    static void a(int x, int y){
        int z = x/y;
        b(z);
    }
    static void b(int x){
        ++x;
    }
}