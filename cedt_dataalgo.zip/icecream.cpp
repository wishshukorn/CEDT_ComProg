#include<iostream>
// #include<utility>
using namespace std;
int main(){
    std::ios_base::sync_with_stdio(false); cin.tie(0);
    int n, m, start;
    // pair<int, int> p;
    int a[n], s[n];
    int p, x;
    // int a[n];
    cin >> n >> m >> start;
    for(int i=0;i<n;i++){
        cin >> a[i] >> s[i];
    }
    for(int i=0;i<m;i++){
        int bath = 0, day = 0, st = start, cnt = 0;
        cin >> p >> x;
        // bath = bath + st;
        do{
            if(day == a[cnt]){
                st = s[cnt];
                cnt++;
            }
            bath = bath + st;
            day++;
            if(day == x){
                bath = 0;
            }
            
            
            // cout << "Here: " << bath << " " << day << endl;
            // cout << (day-1) << " ";
        }while(bath<=p);
        cout << (day-1) << " ";
        // cout << endl;
        // cout << day << " ";

    }
    
    
}