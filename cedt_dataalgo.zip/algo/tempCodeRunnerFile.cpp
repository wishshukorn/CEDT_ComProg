#include<iostream>
using namespace std;

int main(){
    int n, k;
    cin >> n >> k;
    int a, b;
    bool f1=false, f2=false, f3=false, f4=false;
    for(int i=0;i<n;i++){
        f1=false, f2=false, f3=false, f4=false;
        for(int j=0;j<(1<<k)/2;j++){
            cin >> a >> b;
            if(k==1 && a == 0 && b == 1){
                // cout << "yes" << endl;
                continue;
            }else if(k==1){
                // cout << "no" << endl;
                f1 = true;
                continue;
            }

            if(a==b){
                // cout << "no" << endl;
                f2 = true;
                continue;
            }
            if(j==((1<<k)/2)-1 && !(a==0 && b==1)){
                // cout << "no" << endl;
                f3 = true;
                continue;
            }
        }
        if(f1||f2||f3){
            cout << "no" << endl;
        }else{
            cout << "yes" << endl;
        }
        
    }
}