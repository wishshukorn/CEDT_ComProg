#include<iostream>
#include<vector>
#include<queue>
#define base 10
using namespace std;
int getDigit(int v, int k){ // NUM, DIGIT
    int i;
    for(i=0;i<k;i++){
        v /= base;
    }
    return v % base;
}
void radixSort(vector<int> &data, int d){
    queue<int> q[base];
    for(int k=0;k<d;k++){
        for(auto &x : data){            // to queue
            q[getDigit(x, k)].push(x);
        }
        for(int i=0,j=0;i<base;i++){    // from queue
            while(!q[i].empty()){
                data[j++] = q[i].front();
                q[i].pop();
            }
        }
    }

}