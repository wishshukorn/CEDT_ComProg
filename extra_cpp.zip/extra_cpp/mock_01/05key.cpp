#include<iostream>
using namespace std;
int main(){
    int n;
    cin >> n;
    int arr[n+5];
    for(int i=0;i<n;i++){
        cin >> arr[i];
    }
    int ans=0;
    // get subarrays
    for(int w=1;w<=n;w++){
        // start of each window
        for(int i=0;i<=n-w;i++){
            // process each element in the window
            bool is_magical = true;
            bool found[w+1] = {false};
            for(int j=i;j<=i+w-1;j++){
                if(arr[j]<1 || arr[j]>w || found[arr[j]] == true){
                    is_magical = false;
                    break;
                }
                found[arr[j]] = true;
            }
            if(is_magical == true){
                ans++;
            }
        }
    }
    cout << ans;
    return 0;
}