#include<iostream>
using namespace std;
int main(){
    string a;
    while(getline(cin, a)){
        // cout << a.length();
        bool test1=false, test2=false, test3=false, test4=false;
        for(int i=0;i<a.length();i++){
            if((a[i]>=33&&a[i]<=47)||(a[i]>=58&&a[i]<=64)||
            (a[i]>=91&&a[i]<=96)||(a[i]>=123&&a[i]<=126)){
                test1 = true;
            }
            else if(a[i]>=48&&a[i]<=57){
                test2 = true;
            }
            else if(a[i]>=65&&a[i]<=90){
                test3 = true;
            }
            else if(a[i]>=97&&a[i]<=122){
                test4 = true;
            }
        }
        // cout << test1 << test2 << test3 << test4;
        if(a.length()>=12&&test1&&test2&&test3&&test4){
            cout << ">> strong" << endl;
        }else if(a.length()>=8&&test2&&test3&&test4){
            cout << ">> weak" << endl;
        }else{
            cout << ">> invalid" << endl;
        }
    }
}