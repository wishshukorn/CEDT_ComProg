#include<bits/stdc++.h>
using namespace std;
int main(){
    string a, str1, b;
    int cnt=0;
    getline(cin, a);
    getline(cin, str1);
    for(int i=0;i<str1.length();i++){
        if(str1[i]=='"'||str1[i]=='('||str1[i]==')'||str1[i]=='.'||str1[i]=='\''){
            str1[i] = ' ';
        }
    }
    istringstream s(str1);
    while(s>>b){
        if(b==a){
            cnt++;
        }
    }
    cout << cnt;
    return 0;
}