#include<iostream>
using namespace std;
int main(){
    string a;
    getline(cin, a);
    string ch = "abcdefghijklmnopqrstuvwxyz";
    int n[26] = {0};
    for(int i=0;i<ch.length();i++){
        for(int j=0;j<a.length();j++){
            if(a[j] >= 'A' && a[j] <= 'Z'){
                a[j] = a[j] + 32;
            }
            if(ch[i] == a[j]){
                n[i]++;
            }
        }
    }
    for(int i=0;i<ch.length();i++){
        if(n[i]!=0){
            cout << ch[i] << " -> " << n[i] << endl;
        }
    }
    return 0;
}