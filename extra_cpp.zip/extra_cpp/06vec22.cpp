#include<iostream>
#include<vector>
using namespace std;
int main(){
    int a;
    vector<int> v, ans;
    while(cin >> a){
        v.push_back(a);
    }
    for(int i=0;i<v.size();i++){
        if(v[i]==v[i+1]){
            ans.push_back(v[i]);
            ans.push_back(i);
            int j=v[i];
            while(v[i]==j){
                i++;
            }
            ans.push_back(i);
        }
    }
    for(int i=0;i<ans.size();i=i+3){
        cout << ans[i] << " --> x[ " << ans[i+1] << " : " << ans[i+2] << " ]" << endl; 
    }
    return 0;
}