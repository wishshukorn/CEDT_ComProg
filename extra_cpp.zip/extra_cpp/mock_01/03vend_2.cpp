#include<iostream>
using namespace std;
int main(){
    long n, b;
    string a;
    long tot = 0;
    string ss = "";

    cin >> n;
    cin.ignore();
    cin.ignore();
    getline(cin, a);

    for(long i=0;i<a.length();i++){
        if(a[i] == ' '||a[i+1] == '\0'){
            // cout << ss << endl;
            b = stoi(ss);
            tot = tot + b;
            ss = "";
            continue;
        }
        else if(!(isalpha(a[i]))){
            ss = ss + a[i];
        }
    }
    cout << (tot*n);
}