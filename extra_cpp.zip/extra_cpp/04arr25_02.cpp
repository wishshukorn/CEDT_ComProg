#include<iostream>
using namespace std;

int mm(int a[], int start, int end){
    int mx = a[start];
    for(int i=start+1;i<=end;i++){
        if(mx < a[i]){
            mx = a[i];
        }
    }
    return mx;
}

int main(){
    int n, ans = 0;
    cin >> n;
    int a[n];
    for(int i=0;i<n;i++){
        cin >> a[i];
    }
    for(int i=1;i<n-1;i++){
        int mxl = mm(a, 0, i);
        int mxr = mm(a, i, n-1);
        ans = ans + (min(mxl, mxr) - a[i]);
    }
    cout << ans;
    return 0;
}