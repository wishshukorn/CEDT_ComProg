//03loop12.cpp

#include<iostream>
#include<cmath>
using namespace std;
// int main(){
//     double a;
//     cin >> a;
//     double l=0, u=a;
//     double x = (u+l)/2;
//     while((abs(a-pow(x, 2))) > (pow(10,-10)) * (max(a, (pow(x, 2))))){
//         if(pow(x, 2) > a){
//             u=x;
//         }
//         if(pow(x, 2) < a){
//             l=x;
//         }
//         x = (u+l)/2;
//     }
//     cout << x;
//     return 0;
// }

int main(){
    double a;
    cin >> a;
    double l=0, u=a;
    double x = (u+l)/2;
    while((abs(a-pow(10, x))) > (pow(10,-10)) * (max(a, (pow(10, x))))){
        if(pow(10, x) > a){
            u=x;
        }
        if(pow(10, x) < a){
            l=x;
        }
        x = (u+l)/2;
    }
    cout << x;
    return 0;
}