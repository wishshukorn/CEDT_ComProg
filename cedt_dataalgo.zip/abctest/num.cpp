#include "b.h"
#include "c.h"
int main(){
    b b1;
    c c1;
}

/*
#ifndef A_H
#define A_H
class a{
    int m1, m2;
};
#endif

class b{
    a x;
};

// #ifndef A_H
// #define A_H
// class a{
//     int m1, m2;
// };
// #endif

class c{
    a y;
};

int main(){
    b b1;
    c c1;
}

*/