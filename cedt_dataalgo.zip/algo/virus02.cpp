#include<iostream>
#include<cmath>
using namespace std;
int a[256], n, k, m;

int isVirus(int l, int n, int d){
    if(n==2){
        return !(a[l] ^ d) && (a[l^1] ^ d);
    }
    n >>= 1;
    int l1 = l + n * d, l2 = l + n * (!d);
    return isVirus(l2, n, d) && (isVirus(l1, n, 0) || isVirus(l1, n, 1));
}

int main(){
    cin >> n >> k;
    while(m = 1 << k, n--){
        for(int i=0;i<m;i++){
            cin >> a[i];
        }
        if(isVirus(0, m, 0)){
            cout << "yes";
        }else{
            cout << "no";
        }
    }
}