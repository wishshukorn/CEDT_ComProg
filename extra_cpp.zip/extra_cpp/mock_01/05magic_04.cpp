#include <iostream>
using namespace std;

int main () {

    int n;
    cin >> n;
    int list [n];
    int count =0;
    int c_i =0;
    int sum =0;

    
    //input
    for (int i= 0; i< n; i++){
        cin >> list[i];
    }

    //count

    for (int c= 1; c<=n; c++){

        if (c == 1){
            for (int i =0; i< n; i++){

                if (list[i] == 1){

                    count++;

                }

            }

        }

        if (c >= 2){

            for (int i = 0; i <= n-c ; i++){

                for (int j = i; j <= n; j++){

                    if (c_i >= c){
                        

                        if (sum == (c*(c+1))/2){
                            //check
                            // cout << sum << " " << (c*(c+1))/2 << endl;
                            count++;
                        }

                        sum = 0;
                        c_i = 0;
                        break;

                    }

                    c_i++;
                    sum += list[j];

                }

            }
        }

    }


    cout << count;


}