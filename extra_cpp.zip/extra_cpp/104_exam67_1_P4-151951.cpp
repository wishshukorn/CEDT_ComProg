//ENG_EXAM_WEEK
#include<iostream>
using namespace std;
int main(){
    int n;
    cin >> n;
    long a[n*2], b[n]={0};

    for(int i=0;i<n;i++){
        cin >> a[i];
    }
    for(int i=n, j=0; i<n*2; i++, j++){
        a[i] = a[j];
    }
    for(int i=0;i<n;i++){
        long la = a[i];
        b[i] = b[i] + a[i];
        long cnt = 0;
        // int ccc = 0;
        for(int j=i+1;j<n*2;j++){
            // ccc++;
            if(la<=a[j]){
                b[i] = b[i] + a[j];
            }else if(la>a[j]&&cnt==0){
                cnt++;
                continue;
            }else if(la>a[j]){
                break;
            }
            la = a[j];
        }
    }
    long mx = b[0];
    for(int i=0;i<n;i++){
        // cout << b[i] << endl;
        if(b[i]>mx){
            mx = b[i];
        }
    }
    cout << mx << endl;
    
    return 0;
}