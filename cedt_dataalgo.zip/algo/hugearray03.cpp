#include<iostream>
#include<vector>
#include<utility>
#include<algorithm>
using namespace std;
int main(){
    std::ios_base::sync_with_stdio(0); cin.tie(0);
    int n, q;
    int a, b;
    cin >> n >> q;
    pair<int, int> v[n];
    for(int i=0;i<n;i++){
        cin >> v[i].first >> v[i].second;
        // while(b--){
        //     v.push_back(a);
        // }
    }
    sort(v, v+n);
    for(int i=1;i<n;i++){
        v[i].second = v[i].second + v[i-1].second;
        // cout << v[i].second << endl;
    }
    for(int i=0;i<q;i++){
        cin >> a;
        // int j=0;
        // while(v[j].second<a){
        //     j++;
        // }
        int l=0,r=n;
        while(l<r){
            int mid = l + (r-l)/2;
            if(v[mid].second < a){
                l=mid+1;
            }else{
                r = mid;
            }
        }
        cout << v[l].first << endl;
    }
    
}