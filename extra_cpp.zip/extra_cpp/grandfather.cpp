#include<iostream>
#include<map>
using namespace std;
int main(){
    ios_base::sync_with_stdio(false); cin.tie(0);
    long long m, n, a, b;
    map<long long, long long> ma;
    cin >> m >> n;
    for(long long i=0;i<m;i++){
        cin >> a >> b;
        ma[b] = a;
    }
    for(long long i=0;i<n;i++){
        cin >> a >> b;
        long long isGrand1 = ma[ma[a]];
        long long isGrand2 = ma[ma[b]];
        if(isGrand1==0||isGrand2==0||isGrand1 != isGrand2 || a==b){
            cout << "NO" << endl;
        }else{
            cout << "YES" << endl;
        }
    }
    return 0;
}