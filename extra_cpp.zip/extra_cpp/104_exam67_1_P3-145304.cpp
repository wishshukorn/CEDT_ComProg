#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;

int main(){
    double l=-1, u=1, x=(u+l)/2;
    int n;
    cin >> n;
    double a[n+1];

    for(int i=0;i<n+1;i++){
        cin >> a[i];
    }

    double sum = 0;
    for(int i=0;i<n+1;i++){
        sum = sum + (a[i] / (pow((1+x), i)));
    }
    while(abs(sum) > pow(10, -8)){

        sum = 0;
        // sum = sum + (a[0] / (pow((1+x), 0)));

        for(int i=0;i<n+1;i++){
            sum = sum + (a[i] / (pow((1+x), i)));
        }

        // cout << sum << endl;

        if(sum>0){
            l=x;
            x=(u+l)/2;
        }else if(sum<0){
            u=x;
            x=(u+l)/2;
        }else{
            cout << x << endl;
            break;
        }

    }

    cout << setprecision(8) << x << endl;
    return 0;
}