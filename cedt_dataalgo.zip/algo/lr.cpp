#include<iostream>
using namespace std;

int main(){
    int k, n, s;
    cin >> k >> n;
    int c[k+1], a[k], r[n+1];

    for(int i=1;i<=k;i++){
        cin >> s;
        c[i] = s;
    }
    for(int i=0;i<k;i++){
        cin >> s;
        a[i] = s;
        r[i] = s;
    }
    for(int i=k;i<=n;i++){
        r[i] = 0;
        for(int j=1;j<=k;j++){
            r[i] = r[i] + c[j]*r[i-j];
            r[i] = r[i] % 32717;
        }
    }
    cout << r[n];
}