#include<iostream>
using namespace std;
int main(){
    int n, sum = 0;
    cin >> n;
    int a[n];
    for(int i=0;i<n;i++){
        cin >> a[i];
    }
    for(int i=0;i<n;i++){
        if(a[i]>a[i+1]){
            int j=i+1;
            int k=i-1;
            while(a[j]<a[i]){
                sum = sum + (a[i]-a[j]);
                j++;
            }
        }
    }
}