#include<bits/stdc++.h>
using namespace std;
int main(){
    // string ss = "AJQK";
    // string snum = "0123456789";

    int a, b;
    cin >> a >> b;
    string aa[a], bb[b];

    bool havea = false;

    int suma = 0;
    int sumb = 0;

    int cnta = 0;
    int cntb = 0;

    for(int i=0;i<a;i++){
        cin >> aa[i];
    }
    for(int i=0;i<a;i++){
        if(aa[i]=="2") suma = suma + 2;
        else if(aa[i]=="3") suma = suma + 3;
        else if(aa[i]=="4") suma = suma + 4;
        else if(aa[i]=="5") suma = suma + 5;
        else if(aa[i]=="6") suma = suma + 6;
        else if(aa[i]=="7") suma = suma + 7;
        else if(aa[i]=="8") suma = suma + 8;
        else if(aa[i]=="9") suma = suma + 9;
        else if(aa[i]=="10") suma = suma + 10;
        else if(aa[i]=="J"||aa[i]=="Q"||aa[i]=="K"){
            suma = suma + 10;
        }else if(aa[i]=="A"){
            suma = suma + 1;
            havea = true;
            cnta++;
        }
    }
    for(int i=0;i<cnta;i++){
        if(21-suma>=10&&havea){
            suma = suma + 10;
        }
    }
    // cout << suma;

    for(int i=0;i<b;i++){
        cin >> bb[i];
    }
    havea = false;
    for(int i=0;i<b;i++){
        if(bb[i]=="2") sumb = sumb + 2;
        else if(bb[i]=="3") sumb = sumb + 3;
        else if(bb[i]=="4") sumb = sumb + 4;
        else if(bb[i]=="5") sumb = sumb + 5;
        else if(bb[i]=="6") sumb = sumb + 6;
        else if(bb[i]=="7") sumb = sumb + 7;
        else if(bb[i]=="8") sumb = sumb + 8;
        else if(bb[i]=="9") sumb = sumb + 9;
        else if(bb[i]=="10") sumb = sumb + 10;
        else if(bb[i]=="J"||bb[i]=="Q"||bb[i]=="K"){
            sumb = sumb + 10;
        }else if(bb[i]=="A"){
            sumb = sumb + 1;
            havea = true;
            cntb++;
        }
    }
    for(int i=0;i<cntb;i++){
        if(21-sumb>=10&&havea){
            sumb = sumb + 10;
        }
    }
    // cout << sumb;

    if(suma>21&&sumb>21){
        cout << "Draw" << endl;
    }else if(abs(21-suma)<abs(21-sumb) || (suma<=21&&sumb>21)){
        cout << "A" << endl;
    }else if(abs(21-suma)>abs(21-sumb) || (suma>21&&sumb<=21)){
        cout << "B" << endl;
    }else{
        cout << "Draw" << endl;
    }
    cout << suma << " " << sumb << endl;
    
}