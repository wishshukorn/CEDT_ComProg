#include<iostream>
#include<vector>
using namespace std;
int main(){
    ios_base::sync_with_stdio(false); cin.tie(NULL);
    int n, m;
    cin >> n >> m;
    vector<int> a(n);
    int b;
    
    
    for(int i=0;i<n;i++){
        cin >> a[i];
    }
    for(int i=0;i<m;i++){
        cin >> b;
        int j=0, cnt=0;
        while(a[j]!=b){
            if(a[j]>b){
                cnt++;
            }
            j++;
        }
        cout << cnt << endl;
    }
}