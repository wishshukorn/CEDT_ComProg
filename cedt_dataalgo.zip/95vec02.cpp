#include<iostream>
using namespace std;
class test{
    public:
        test() : data(){
            cout << "created" << endl;
        }
        ~test() {
            cout << data << " destroyed" << endl;
        }
        int data;
};

int main(){
    cout << "-- Life cycle --" << endl << "- normal object -" << endl;
    test u;
    u.data = 99;
    for(int i=0;i<5;i++){
        test t;
        t.data = i*10;
    }
}