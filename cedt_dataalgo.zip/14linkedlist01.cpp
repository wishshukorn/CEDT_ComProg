/*
#include<iostream>
using namespace std;

struct Node{
    int data; // data
    Node *link; // pointer
};

typedef Node* nodePtr;

int main(){
    nodePtr head;
    head = headNode;
    headNode -> data = 20;
    headNode -> link = NULL;
    cout << head -> data << endl;
}
*/

#include<iostream>
using namespace std;

struct Node{
    int data;
    Node* next;
};

class LinkedList{
    Node* head;

public:

    LinkedList() :head(NULL){}

    void insertAtTheBeginning(int value){
        Node* newNode = new Node();
        newNode -> data = value;
        newNode -> next = head;
        head = newNode;
    }
    void insertAtEnd(int value){
        Node* newNode = new Node();
        newNode -> data = value;
        newNode -> next = NULL;
        if(!head){
            head = newNode;
            // return;
        }
        Node* temp = head;
        while(temp -> next){
            temp = temp -> next;
        }
        temp -> next = newNode;
    }
    void insertAtPosition(int value, int position){
        if(position<1){
            cout << "Position should be >= 1" << endl;
        }
        if(position == 1){
            insertAtTheBeginning(value);
        }
        Node* newNode = new Node();
        newNode -> data = value;

        Node* temp = head;
        for(int i=1;i<position-1&&temp;i++){
            temp = temp -> next;
        }

        if(!temp){
            cout << "Position out of range." << endl;
            delete newNode;
        }
        newNode -> next = temp -> next;
        temp -> next = newNode;
    }
};
