#include<iostream>
#include<vector>
#include<algorithm>
// #include<bits/stdc++.h>
using namespace std;
int main(){
    std::ios_base::sync_with_stdio(false); std::cin.tie(0);
    int m, n, k, a;
    // pair<int, int> sec;
    vector<int> fir, ans;
    cin >> m >> n >> k;
    for(int i=0;i<m;i++){
        cin >> a;
        fir.push_back(a);
    }
    sort(fir.begin(), fir.end());
    while(n--){
        cin >> a;
        auto l = lower_bound(fir.begin(), fir.end(), a-k);
        auto u = upper_bound(fir.begin(), fir.end(), a+k);
        // int sum = u-l;
        cout << u-l << " ";
        // cnt = 0;
        // sec = make_pair(a-k, a+k);
        // for(int i=0;i<m;i++){
        //     if(fir[i]>=a-k&&fir[i]<=a+k){
        //         cnt++;
        //         continue;
        //     }
        // }
        // ans.push_back(sum);
    }
    // for(int i=0;i<ans.size();i++){
    //     cout << ans[i] << " ";
    // }
    return 0;
}