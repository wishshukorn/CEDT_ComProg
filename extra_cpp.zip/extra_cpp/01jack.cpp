#include<iostream>
using namespace std;
// int main(){
//     string a[] = {"","fee", "fie", "foe", "fum", "fot"};
//     int num;
//     cin >> num;
//     cout << a[num%5];
//     for(int i=0;i<(num/5);i++){
//         cout << a[5];
//     }
//     return 0;
// }

int main(){
    string a[] = {"fee", "fie", "foe", "fum", "fot"};
    int num;
    cin >> num;
    cout << a[(num-1)%5];
    for(int i=0;i<((num-1)/5);i++){
        cout << a[4];
    }
    return 0;
}