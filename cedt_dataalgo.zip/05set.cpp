#include<iostream>
#include<set>
using namespace std;
// int main(){
//     set<int> s = {4, 1, 3, 2, 1, 1, 3, 4};
//     cout << "Size of s is " << s.size() << endl;
//     s.insert(10);
//     s.insert(5);
//     s.erase(3);
//     cout << "Member of s: ";
//     for(auto it = s.begin();it!=s.end();it++){
//         cout << *it << " ";
//     }
// }

int main(){
    set<pair<string, int>> s = {{"somchai", 5}, {"abc", 6}, {"abcd", -3}, {"somchai", -4}, {"z", 0}, {"z", -1}, {"z", 9}};
    for(auto &x : s){
        cout << x.first << ", " << x.second << endl;
    } 
    cout << "--find--" << endl;
    auto it = s.find({"z", -1});
    cout << (*it).first << ", " << (*it).second << endl;
    it--;
    it--;
    cout << it -> first << ", " << it -> second << endl;
    it++;
    cout << it -> first << ", " << it -> second << endl;
}