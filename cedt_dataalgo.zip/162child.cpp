class node{
    friend class map_bst;
    protected:
        ValueT data;
        node *left;
        node *right;
        node *parent;
        node():
            data(ValueT()), left(NULL), right(NULL), parent(NULL) {}
        // node(const ValueT)
}

node* find_node(const ValueT& k, node* r, node* &parent){
    node *ptr = r;
    while(ptr != NULL){
        int cmp = compare(k, ptr->data);
        if(cmp == 0){
            return ptr;
        }
        parent = ptr;
        ptr = cmp < 0 ? ptr->left : ptr->right;
    }
    return NULL;
}