#include<iostream>
#include<cmath>
using namespace std;

long gcd(long a, long b){
    if(b==0){
        return a;
    }
    return gcd(b, a%b);
}

int main(){
    string a, b, c;
    cin >> a >> b >> c;
    // int len = b.length()+c.length();
    // cout << len;
    // return 0;
    // int fir = stoi(b+c)-stoi(c);
    // int sec = ((pow(10, b.length()))-1)*(pow(10, c.length()));
    // // gcd(fir, sec);
    // fir = fir/(gcd(fir, sec));
    // sec = sec/(gcd(fir, sec));

    int fir = stoi(a+b+c)-stoi(a+b);
    int sec = pow(10, (b.length()+c.length())) - pow(10, b.length());
    int ma = gcd(fir, sec);
    fir = fir/ma;
    sec = sec/ma;
    cout << fir << " / " << sec;
    return 0;


}