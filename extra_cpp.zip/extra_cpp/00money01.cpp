#include<iostream>
using namespace std;
int main(){
    int a;
    int b[9] = {1000, 500, 100, 50, 20, 10, 5, 2, 1};
    cin >> a;
    for(int i : b){
        // cout << i << endl;
        cout << "[" << i << "] = " << a/i << endl;
        // a = a - (i*(a/i));
        a = a%i;
    }
    return 0;
}