#include<iostream>
#include<vector>

using namespace std;

// dynamic array
void printUniqueWords(std::string filename){
    int cap = 1;
    std::string *words;
    words = new std::string[cap];
    int n = 0;
    if(n==cap){
        std::string *a = new std::string[2*cap];
        for(int i=0;i<n;i++){
            a[i] = words[i];
        }
        delete[] words;
        words = a;
        cap = cap * 2;
    }
}

// vector
// O(n)
/*
void printUniqueWords3(string filename){
    vector<string> words;
    Tokenizer tokenizer(filename);
    while(tokenizer.hasNext()){
        string token = tokenizer.next();
        if(words.end() == find(words.begin(), words.end(), token)){
            words.push_back(token);
        }
    }
    tokenizer.close();
    cout << words.size() << endl;
}
*/

// set
// O(log n)
/*
void printUniqueWords3(string filename){
    set<string> words;
    Tokenizer tokenizer(filename);
    while(tokenizer.hasNext()){
        string token = tokenizer.next();
        if(words.end() == words.find(token)){
            words.insert(token);
        }
    }
    tokenizer.close();
    cout << words.size() << endl;
}
*/
