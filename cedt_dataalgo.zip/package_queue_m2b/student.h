#ifndef __STUDENT_H_
#define __STUDENT_H_

#include <algorithm>
#include <iostream>


template <typename T>
void CP::queue<T>::move_to_back(size_t pos) {
  //write your code here
  // CP::queue<T> t;
  // T d = mData[pos];
  // push(d);
  // for(int i=mSize-1;i>=pos;i--){
  //   mData[i-1] = mData[i];
  // }
  // mSize--;
  // T a = mData[pos];
  
  // for(int i=pos;i<mSize-1;i++){
  //   mData[(i+mFront)%mCap] = mData[(i+1+mFront)%mCap];
  // }
  // mSize--;
  // push(a);
  // std::swap(mData[(mFront+pos+1)%mCap], mData[(mFront+(mSize-1))%mCap]);
  for(size_t i=pos;i<mSize-1;i++){
    std::swap(mData[(i+mFront)%mCap],mData[(i+1+mFront)%mCap]);
  }

}

#endif
