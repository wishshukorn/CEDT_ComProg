#include "a.h"
class b{
    a x;
};