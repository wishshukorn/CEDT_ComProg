#include<iostream>
#include<tuple>
using namespace std;

string to_str(tuple<string, int, int>tt, int i){

}

int main(){
    tuple<string, int, int> t1 = make_tuple("abc", 2, 3);
    tuple<string, int, int> t2 = make_tuple("a", 2, 3);
    tuple<string, int, int> t3[2] = make_tuple("cba", 1, 10);
    t3[2] = make_tuple("xyz", 100, 200);
    
    // cout << to_str(t3, 0) << endl;
    return 0;
}