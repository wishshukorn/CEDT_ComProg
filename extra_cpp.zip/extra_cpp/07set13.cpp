#include<iostream>
#include<set>
using namespace std;
int main(){
    string a, b;
    set<string> s1, s2;
    bool is = true;
    while(cin >> a >> b){
        s1.insert(a);
        s2.insert(b);
    }
    for(auto i=s1.begin();i!=s1.end();i++){
        if(s2.find(*i)!=s2.end()){
            continue;
        }else{
            cout << *i << " ";
            is = false;
        }
    }
    if(is){
        cout << "None";
    }
    return 0;
}
/*
    for(auto i=s1.begin();i!=s1.end();i++){
        bool is = false;
        for(auto j=s2.begin();j!=s2.end();j++){
            if(*i==*j){
                is = true;
                break;
            }
        }
        if(is){
            cout << *i;
        }
    }
*/