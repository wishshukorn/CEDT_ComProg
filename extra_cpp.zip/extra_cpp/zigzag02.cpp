#include<iostream>
using namespace std;
int main(){
    int a, b, cnt=0;
    int minl=2e9, minr=2e9, maxl=-2e9, maxr=-2e9;
    cin >> a >> b;
    while(true){
        if(cnt%2==0){
            minl = min(minl, a);
            maxl = max(maxl, a);
            
            minr = min(minr, b);
            maxr = max(maxr, b);
        }else{
            minl = min(minl, b);
            maxl = max(maxl, b);

            minr = min(minr, a);
            maxr = max(maxr, a);
        }
        cnt++;
        cin >> a;
        if(a==-998||a==-999){
            break;
        }
        cin >> b;
    }
    if(a==-998){
        cout << minl << " " << maxr;
    }else{
        cout << minr << " " << maxl;
    }

}