#include<iostream>
using namespace std;
int main(){
    int a;
    cin >> a;
    if(a<2){
        return 0;
    }
    for(int i=a;i>0;i--){
        for(int j=0;j<(i-1);j++){
            cout << '.';
        }
        if(i==a){
            cout << '*';
        }else if(i!=1){
            cout << '*';
            for(int k=0;k<(2*(a-i))-1;k++){
                cout << '.';
            }
            cout << '*';
        }else{
            for(int k=0;k<(a*2)-1;k++){
                cout << '*';
            }
        }
        cout << endl;
    }
}