#include<iostream>
#include<vector>
#include<algorithm>

int main(){
    int a[2] = {10, 20};
    // int a[0];
    // int a[1];
    // a[0] = 10;
    // a[1] = 20;
    for(int i=0;i<sizeof(a)/sizeof(a[0]);i++){
        std::cout << a[i] << " ";
    }
    std::cout << std::endl;
    for(int i=0;i<std::size(a);i++){
        std::cout << a[i] << " ";
    }
    std::cout << std::endl;

    std::vector<int> b = {2, 3};
    std::vector<bool> c = {true, false, true};

    b.push_back(10);
    b.insert(b.begin(), 99);
    b.insert(b.end(), -5);

    std::sort(b.begin(),b.end());

    for(size_t i=0;i<b.size();i++){
        std::cout << b[i] << " ";
    }
    std::cout << std::endl;
    for(size_t i=0;i<c.size();i++){
        std::cout << c[i] << " ";
    }
    return 0;
}