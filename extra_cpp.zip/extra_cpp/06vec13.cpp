#include <iostream> 
#include <vector> 
 
using namespace std; 
 
vector<string> split(string line, char delimiter) { 
    // เขยนคำสงในฟงกชนนเทำนน ไมเปลยนแปลงคำสงอน ๆ นอกฟงกชนน 
    vector<string> a;
    string s = "";
    for(int i=0;i<line.length();i++){
        if(line[i]==delimiter){
            continue;
        }
        s = s + line[i];
        if(line[i+1]==delimiter||line[i+1]=='\0'){
            a.push_back(s);
            s = "";
        }
    }
    return a;
} 

int main() { 
    string line; 
    getline(cin, line); 
    string delim; 
    getline(cin, delim); 
    for (string e : split(line, delim[0])) { 
        cout << '(' << e << ')'; 
    } 
}