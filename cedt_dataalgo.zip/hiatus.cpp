#include<iostream>
#include<map>
#include<utility>
#include<set>

using namespace std;
int main(){
    std::ios_base::sync_with_stdio(false); std::cin.tie(0);
    int n, m, a, b;
    pair<int, int> p;
    set<pair<int, int>> s;
    multimap<int, int> mm;

    cin >> n >> m;
    for(int i=0;i<n;i++){
        cin >> a >> b;
        s.insert(make_pair(a, b));
        // mm[a] = b;
    }
    for(int i=0;i<m;i++){
        cin >> a >> b;

        auto it = s.lower_bound({a,b});

        if(s.find({a, b})!=s.end()){
            cout << "0 0 ";
            continue;
        }else if(it == s.begin()){
            cout << "-1 -1 ";
        }
        else{
            
            --it;
            cout << it -> first << " " << it -> second << " ";


        }
    }
    // for(auto it : s){
    //     cout << it.first << " " << it.second << endl;
    // }
}