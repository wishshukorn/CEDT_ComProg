int fibo_memo(int n){
    if(n==1||n==0){
        return n;
    }
    if(n>=2){
        if(table[n]>0){
            return table[n];
        }
        int value = fibo_memo(n-1) + fibo_memo(n-2);
        table[n] = value;
        return value;
    }
}

int fibo_buttom_up(int n){
    value[0] = 0;
    value[1] = 1;
    for(int i=2;i<n;i++){
        value[i] = value[i-1] + value[i-2];
    }
    return value[n];
}

int Bino_naive(int n, int r){
    if(r == n) {
        return 1;
    }
    if(r == 0) {
        return 1;
    }
    int result = Bino_naive(n-1, r) + Bino_naive(n-1, r-1);
    return result;
}

int bino_mem(int n, int r){
    if(r==n){
        return 1;
    }
    if(r==0){
        return 1;
    }
    if(table[n][r] != -1){
        return table[n][r];
    }
    int result = bino_mem(n-1, r) + bino_mem(n-1, r-1);
    table[n][r] = result;
    return result;
}

int bino_dp(int n, int r){
    for(int i=0;i<=n;i++){
        table[i][0] = 1;
        table[i][i] = 1;
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<i;j++){
            table[i][j] = table[i-1][j] + table[i-1][j-1];
        }
    }
    return table[n][r];
}

int mcm(int l, int r){
    if(l<r){
        micCost = MAX_INT;
        ffor(int i=l;i<r;i++){
            my_cost = mcm(l, i) + mcm(i+1, r) +(a[l] * a[i+1] * a[r+1]);
            minCost = min(my_cost, minCost);
        }
        return minCost;
    }else{
        return 0;
    }
}