#include<iostream>
#include<set>
using namespace std;
int main(){
    int m, n, a;
    multiset<int> s1, s2;
    cin >> m >> n;
    for(int i=0;i<m;i++){
        cin >> a;
        s1.insert(a);
    }
    for(int i=0;i<n;i++){
        bool isPair = false;
        cin >> a;
        for(auto j:s1){
            if(s1.find(a-j)!=s1.end()&&a-j!=j){
                cout << "YES" << endl;
                isPair = true;
                break;
            }
        }
        if(!isPair){
            cout << "NO" << endl;
        }
        
    }
    // for(auto i=s2.begin();i!=s2.end();i++){
    //     for(int j=0;j<s1.size()/2;j++){
    //         auto k = s1.begin();
    //         if(s1.find((*i)-(*k))==s1.end()){
    //             cout << "YES" << endl;
    //             break;
    //         }else{
    //             cout << "NO" << endl;
    //             break;
    //         }
    //         k++;
    //     }
    // }
}