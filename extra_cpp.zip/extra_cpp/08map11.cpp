// #include<iostream>
// #include<map>
// using namespace std;
// int main(){
//     int n, m;
//     string s1, s2;
//     map<string, string> m1;
//     cin >> n;
//     for(int i=0;i<n;i++){
//         cin >> s1 >> s2;
//         m1[s1] = s2;
//     }
//     cin >> m;
//     for(int i=0;i<m;i++){
        
//     }


// }

#include<iostream>
#include<map>
using namespace std;
int main(){
    int n;
    string a, b;
    map<string, string> m;
    while(n--){
        cin >> a >> b;
        m[a] = b;
    }
    cin >> n;
    while(n--){
        cin >> a;
        if(m.find(a)!=m.end()){
            cout << m[a] << endl;
        }else{
            for(auto& it:m){
                if(it.second==a){
                    cout << it.first << endl;
                    continue;
                }
            }
        }
    }
}