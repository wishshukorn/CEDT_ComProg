#include<iostream>
#include<vector>
using namespace std;

void perm(int n, vector<int> &sol, int len, vector<bool> &used){
    if(len<n){
        for(int i=1;i<=n;i++){
            if(used[i] == false){
                used[i] = true;
                sol[len] = i;
                perm(n, sol, len+1, used);
                used[i] = false;
            }
        }
    }else{
        for(auto &x : sol){
            cout << x;
        }
    }
}

void permk(int n, vector<int> &sol, int len, vector<bool> &used, int k){
    if(len<k){
        for(int i=1;i<=n;i++){
            if(used[i] == false){
                used[i] = true;
                sol[len] = i;
                permk(n, sol, len+1, used, k);
                used[i] = false;
            }
        }
    }else{
        for(auto &x : sol){
            cout << x;
        }
    }
}

// can use again
void permk_replace(int n, vector<int> &sol, int len, vector<bool> &used, int k){
    if(len<k){
        for(int i=1;i<=n;i++){
            
                sol[len] = i;
                permk_replace(n, sol, len+1, used, k);
           
            
        }
    }else{
        for(auto &x : sol){
            cout << x;
        }
    }
}

void combi(int n, vector<int> &sol, int len){
    if(len<n){
        sol[len] = 0;
        combi(n, sol, len+1);
        sol[len] = 1;
        combi(n, sol, len+1);
    }else{
        for(int i=0;i<n;i++){
            if(sol[i]==1){
                cout << i+1 << " ";
            }
        }
        cout << "." << endl;
    }
}

void combi_kn(int n, vector<int> &sol,int len, int k, int chosen){
    if(len<n){
        sol[len] = 0;
        combi_kn(n, sol, len+1, k, chosen);
        if(chosen<k){
            sol[len] = 1;
            combi_kn(n, sol, len+1, k, chosen+1);
        }
    }else{
        for(int i=0;i<n;i++){
            if(sol[i]==1){
                cout << i+1 << " ";
            }
        }
        cout << endl;
    }
}

void combi_exact(int n, vector<int> &sol, int len, int k, int chosen){
    if(len<n){
        if(len-chosen < n-k){
            sol[len] = 0;
            combi_exact(n, sol, len+1, k, chosen);
        }
        if(chosen < k){
            sol[len] = 1;
            combi_exact(n, sol, len+1, k, chosen+1);
        }
    }else{
        for(int i=0;i<n;i++){
            if(sol[i] == 1){
                cout << i+1 << " ";
            }
        }
        cout << endl;
    }
}