#include<iostream>
#include<vector>
using namespace std;
int main(){
    int n,m;
    cin>>n>>m;
    vector<int> DP(n+1,0), W(m+1,0);
    for(int i=0;i<m;i++){
        cin>>W[i];
    }
    DP[0]=1;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            if(i+W[j]<=n){
                DP[i+W[j]]=(DP[i+W[j]]+DP[i])%1000003;
            }
        }
    }
    cout<<DP[n];
}