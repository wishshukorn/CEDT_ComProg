#include<iostream>
using namespace std;
int main(){
    string a;
    getline(cin, a);
    string num = "0123456789";
    for(int i=0;i<a.length();i++){
        for(int j=0;j<num.length();j++){
            if(a[i]==num[j]){
                num.erase(num.begin()+j);
            }
        }
    }
    if(num.empty()){
            cout << "None";
    }
    for(int j=0;j<num.length();j++){
            cout << num[j];
        if(j!=num.length()-1){
            cout << ",";
        }
    }
}
