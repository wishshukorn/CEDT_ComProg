#include<iostream>
using namespace std;

int main(){
    int n;
    cin >> n;
    string a[n], b[n];
    string ss;
    for(int i=0;i<n;i++){
        cin >> a[i];
    }
    cin.ignore();
    getline(cin, ss);
    for(char i : ss){
        if(i=='C'){
            for(int j=0;j<n/2;j++){
                b[j] = a[n/2+j];
                b[n/2+j] = a[j];
            }
            for(int j=0;j<n;j++){
                a[j] = b[j];
            }
        }else if(i=='S'){
            int k=0;
            for(int j=0;j<n;j++){
                
                if(j%2==0){
                    b[j] = a[k];
                    
                }else{
                    b[j] = a[n/2+k];
                    k++;
                }
            }
            for(int j=0;j<n;j++){
                a[j] = b[j];
            }

        }
    }
    for(int i=0;i<n;i++){
        cout << a[i] << " ";
    }
}