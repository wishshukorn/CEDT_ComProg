// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     string s;
//     int a;
//     cin >> s >> a;
    // if(!(a>1&&a<1000)){
    //     return 0;
    // }
//     char fir=s[0];
//     int cnt=0;
//     vector<char> arr1;
//     for(int i=0;i<s.length();i++){
//         if(fir==s[i]){
//             cnt++;
//             arr1.push_back(fir);
//         }else{
//             if(cnt<a){
//                 for(int j=1;j<=arr1.size();j++){
//                     cout << arr1[arr1.size()-j];
//                 }
//                 arr1.clear();
//             }else{
//                 arr1.clear();
//             }
//             cnt = 1;
//             fir = s[i];
//             arr1.push_back(fir);
//         }
//     }
// if(cnt<a){
//     for(int j=1;j<=arr1.size();j++){
//         cout << arr1[arr1.size()-j];
//     }
//     arr1.clear();
// }else{
//     arr1.clear();
// }
// }

// // #include<iostream>
// // using namespace std;
// // int main(){
// // string a;
// // getline(cin ,a);
// // char fir = a[0];
// // int cnt=0;
// // for(int i=0;i<a.length();i++){
// //     if(fir==a[i]){
// //         cnt++;
// //     }else if(fir!=a[i]){
// //         cout << fir << ' ' << cnt << ' ';
// //         fir = a[i];
// //         cnt = 1;
// //     }
// // }
// // cout << fir << ' ' << cnt << ' ';

// // }

#include<bits/stdc++.h>
using namespace std;
int main(){
    string a;
    int num;
    cin >> a >> num;
    char fir = a[0];
    int cnt = 0;
    for(int i=0;i<a.length();i++){
        while(fir == a[i]){
            cnt++;
            i++;
        }
        if(cnt<num){
            for(int j=0;j<cnt;j++){
                cout << fir;
            }
        }
        fir = a[i];
        // i = i + cnt;
        cnt = 1;
    }
}