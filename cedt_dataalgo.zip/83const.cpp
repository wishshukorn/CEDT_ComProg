#include<iostream>
#include<queue>

namespace CP{
    template<typename T1, typename T2>
    class pair{
        public:
        T1 first;
        T2 second;

        pair() : first(), second() {}
        

        //custom constructor
        // pair(const T1 &a, const T2 &b){
        //     first = a;
        //     second = b;
        // }
        
        pair(const T1 &a, const T2 &b) : first(a), second(b) {}

        bool operator == (const pair <T1, T2> &other){
            return (first == other.first && second == other.second);
        }
        // this -> first
        bool operator<(const pair <T1, T2> &other) const{
            return ((first < other.first)||(first == other.first && second < other.second));
        }
        // set, map, priority queue
    };
}

int main(){
    CP::pair<int, bool> p(10, false);
    CP::pair<std::string, int> q("abc", 42), r("", 0);
    std::cout << (q<r) << std::endl;
    CP::pair<std::string, int> x(q);
    CP::pair<std::string, int> y = x;
}