#include<iostream>
#include<vector>
using namespace std;

int main(){
    ios_base::sync_with_stdio(0); cin.tie(0);

    int n, a, maxx = 0;
    int arr[5005] = {0};

    cin >> n;

    for(int i=0;i<n;i++){
        int cnt = 0;

        for(int j=0;j<n;j++){
            cin >> a;
            cnt = cnt + a;
        }

        // cout << cnt;
        if(cnt>maxx){
            maxx = cnt;
        }
        arr[cnt]++;
    }

    for(int i=0;i<=maxx;i++){
        cout << arr[i] << " ";
    }
}