#include<iostream>
using namespace std;
int main(){
    string a;
    int num;
    cin >> a >> num;
    cout << "Hello" << endl;
    if(num>1 && num<1000){
        cout << "Hello" << endl;
        return 0;
    }
    char fir = a[0];
    int cnt = 0;
    for(int i=0;i<a.length();i++){
        cout << "Hello" << endl;
        while(fir == a[i]){
            cout << "Hello" << endl;
            cnt++;
            i++;
        }
        if(cnt<num){
            cout << "Hello" << endl;
            for(int j=0;j<cnt;j++){
                cout << fir;
            }
        }
        fir = a[i];
        cnt = 1;
    }
    // cout << "Hello" << endl;
}