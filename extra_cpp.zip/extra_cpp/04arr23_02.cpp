#include<iostream>
using namespace std;
int main(){
    int n;
    cin >> n;
    int a[n], b[n];
    for(int i=0;i<n;i++){
        cin >> a[i] >> b[i];
    }
    // cin.ignore();
    string ss;
    getline(cin, ss);
    return 0;
}