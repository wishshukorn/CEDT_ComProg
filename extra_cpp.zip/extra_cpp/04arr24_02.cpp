#include<iostream>
using namespace std;

void printt(int a[], int n){
    for(int i=0;i<n;i++){
        cout << a[i] << " ";
    }
    cout << endl;
}

int max_index(int a[], int n){
    int ans = 0;
    for(int i=0;i<n;i++){
        if(a[i] > a[ans]){
            ans = i;
        }
    }
    return ans;
}

void flip(int a[], int now){
    for(int i=0, j=now;i<now/2+1;i++, j--){
        swap(a[i], a[j]);
    }
}

int main(){
    int n;
    cin >> n;
    int a[n];
    for(int i=0;i<n;i++){
        cin >> a[i];
    }
    printt(a, n);
    for(int i=n-1;i>0;i--){
        int maxindex = max_index(a, i+1);
        if(maxindex!=i){
            if(maxindex>0){
                flip(a, maxindex);
                printt(a, n);
            } 
            flip(a, i);
            printt(a, n);
        }
        
    }
}