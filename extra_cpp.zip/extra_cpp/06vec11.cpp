#include<iostream>
#include<vector>
using namespace std;
int main(){
    vector<int> a;
    int n, b;
    cin >> n;
    for(int i=0;i<n;i++){
        cin >> b;
        if(i%2==0){
            a.push_back(b);
        }else{
            a.insert(a.begin()+0, b);
        }
    }
    int i=0;
    if(n%2!=0){
        i++;
    }
    while(cin >> b){
        if(b==-1){
            break;
        }
        if(i%2==0){
            a.push_back(b);
        }else{
            a.insert(a.begin()+0, b);
        }
        i++;
    }
    cout << "[";
    for(i=0;i<a.size();i++){
        cout << a[i];
        if(i!=a.size()-1){
            cout << ", ";
        }
    }
    cout << "]";
    return 0;
}