#include<iostream>
using namespace std;

void pass_by_value(int x){ // x is parameter
    cout << "X is " << x << endl;
    x = 30;
}

void pass_by_reference(int &x){
    cout << "X is " << x << endl;
    x = 40;
}

int main(){
    cout << "Pass by Value, direct" << endl;
    pass_by_value(10); // 10 is argument
    cout << endl;

    int x = 20;
    cout << "Pass by value, variable" << endl;
    pass_by_value(x);
    cout << "outside PbT function x = " << x << endl;
    cout << endl;

    cout << "Pass by reference" << endl;
    pass_by_reference(x); // variable
    cout << "outsitde PbR function x = " << x << endl;
}