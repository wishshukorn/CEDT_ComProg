#include<iostream>
using namespace std;

template <typename T>
class node{
    public:
        T data;
        node *next;
        node():
            data(T()), next(NULL) {}
        node(const T & data, node* next):
            data(T(data), next(next)) {}
};

int main(){
    node<int> *p = NULL;
    p = new node<int>(10, NULL);
    node<int> *q;
    q = new node<int>(20, NULL);
    p->next = q;
    q->next = new node<int>(30, NULL);
}

template <typename T>
class list{
    protected:
        class node{
            friend class list;
            public:
            T data;
            node *next;
            node():
                data(T()), next(NULL) {}
            node(const T & datam node* next):
                data(T(data)), next(next) {}
        };
    protected:
        node *mFirst;
        size_t mSize;
    public:
    list(): mFirst(NULL), mSize(0) {}
    ~list(){
        clear();
    }
};

// insert
node<int> *x = mFirst->next->next;
node<int> *d = new node<int>(99, NULL);
mFirst->next-next = d;
d->next = x;

// erase
node<int> *x = mFirst->next->next;
mFirst->next->next = x->next;
delete x;