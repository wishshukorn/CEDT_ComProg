#include<iostream>
#include<vector>
using namespace std;

int cnt = 0;

void choc(int n, int k, int a[], int i, int sum){
    if(i<k&&sum<=n){
        sum = sum + a[i];
        choc(n, k, a, i, sum);
        choc(n, k, a, i+1, sum);

    }else if(sum==n){
        cnt++;
    }

}

int main(){
    int n, k;
    cin >> n >> k;
    int a[k];
    // vector<int> v;
    for(int i=0;i<k;i++){
        cin >> a[i];
    }
    choc(n, k, a, 0, 0);
    cout << cnt << endl;


}