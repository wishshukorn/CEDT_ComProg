#include<iostream>
using namespace std;
int main(){
    int n, k;
    cin >> n >> k;

    int a = (1<<k)/2;
    int b, c;
    bool chk = false;
    bool chk2 = true;
    // cout << a << endl;
    for(int i=0;i<n;i++){
        
        for(int j=0;j<a;j++){
            cin >> b >> c;
            chk = false;
            if(a!=1 && b!=c){
                // cout << "yes" << endl;
                chk = true;
            }
            else if( a==1 && b == 0 && c==1){
                cout << "yes";
                chk2 = false;
            }
            else if(a==1){
                cout << "no";
                chk2 = false;
            }
            // else if(a!=1 && b==c){
            //     // cout << "no" << endl;
            // }

        }
        if(chk && chk2){
            cout << "yes";
        }else if(chk2){
            cout << "no";
        }
    }
}