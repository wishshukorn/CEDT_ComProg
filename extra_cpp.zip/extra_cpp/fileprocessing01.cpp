#include<iostream>
#include<fstream>
// using namespace std;
int main(){
    std::ifstream a;
    a.open("text01.txt");
    std::string s;
    a >> s;
    std::cout << s << std::endl;
    a.close();

    std::ofstream b;
    b.open("text01.txt");
    b << "Hello world!";
    b.close();

    std::ifstream c;
    c.open("text01.txt");
    std::string s1;
    std::getline(c, s1);
    std::cout << s1 << std::endl;
    c.close();

    return 0;
}