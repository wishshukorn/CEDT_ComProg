#include<iostream>
#include<cmath>
using namespace std;
int main(){
    long double n;
    double a;
    double aa;
    cin >> n;
    if(n < 1000){
        cout << n;
    }else if(n < 1000000){
        aa = n/1000;
        // cout << aa << endl;
        if(aa<10){
            a = round((n/1000)*10)/10;
            cout << a;
        }else{
            cout << round(aa);
        }
        cout << "K";
    }else if(n < 1000000000){
        // a = round((n/1000000)*10)/10;
        aa = n/1000000;
        if(aa<10){
            a = round((n/1000000)*10)/10;
            cout << a;
        }else{
            cout << round(aa);
        }
        cout << "M";
    }else{
        // a = round((n/1000000000)*10)/10;
        aa = n/1000000000;
        if(aa<10){
            a = round((n/1000000000)*10)/10;
            cout << a;
        }else{
            cout << round(aa);
        }
        cout << "B";
    }
    return 0;
}