#ifndef __STUDENT_H_
#define __STUDENT_H_


template <typename T>
void CP::vector<T>::erase_many(const std::vector<int> &pos) {
  //write your code here
  // for(int i=0;i<pos.size();i++){
  //   int posSize = mSize;
  //   for(int j=pos[i];j<posSize-1;j++){
  //     mData[j] = mData[j+1];
  //   }
  //   mSize--;
  // }
  T *arr = new T[mSize-pos.size()];
  int cnt = 0;
  int a = 0;
  for(int i=0;i<mSize;i++){
    if(a >= pos.size() || i!=pos[a]){
      arr[cnt++] = mData[i];
      continue;
    }
    a++;
  }
  delete [] mData;
  mData = arr;
  mSize = mSize - pos.size();
  mCap = mSize;

}

#endif

/*
#ifndef STUDENTH
#define STUDENTH


template <typename T>
void CP::vector<T>::erase_many(const std::vector<int> &pos) {
    int posSize = pos.size();
    mSize -= posSize;
    mCap = mSize;
    for (int i = pos[0], j = 0; i < mSize; i++) {
        while (j < posSize && i + j == pos[j])
            j++;
        mData[i] = mData[i + j];
    }
}

#endif
*/