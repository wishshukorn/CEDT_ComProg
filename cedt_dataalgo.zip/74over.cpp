#include<iostream>
#include<queue>
using namespace std;

class Student{
    public:
        Student(float score, string a, string b){
            name = a;
            surname = b;
            gpax = score;
        }
        bool is1stHonor(){
            return gpax >= 3.6;
        }
        string name, surname;
        float gpax;
        bool operator<(const Student & other) const{
            return gpax < other.gpax;
        }
};

int main(){
    Student a(2.95, "nattee", "niparnan");
    Student b(4.00, "wish", "term");
    cout << (a<b) << endl;
    priority_queue<Student> pq;
    pq.push(a);
    pq.push(b);
    cout << pq.top().name << endl;
    priority_queue<int> test;
    test.push(10);
    test.push(20);
    test.push(30);
    cout << test.top() << endl;
    
}