// #include<iostream>
// #include<string>
#include<bits/stdc++.h>
using namespace std;
int main(){
    string a, str1;
    int cnt=0, ans=0;
    int count=0;
    getline(cin, a);
    getline(cin, str1);
    for(int i=0;i<str1.length();i++){
        if(str1[i]=='"'||str1[i]=='('||str1[i]==')'||str1[i]=='.'||str1[i]=='\''){
            str1[i] = ' ';
        }
        
        
        
        // a = ' ' + a + ' ';
        // cout << a;
        // if(a[0]==str1[i]){
        //     cnt=0;
        //     if((str1[i-1]!=' '||str1[i-1]!='\0')&&(str1[i+a.length()+1]!=' '||str1[i+a.length()+1]!='\0')){
        //         cnt++;
        //     }
        //     for(int j=0;j<a.length();j++){
        //         if(a[j]==str1[i+j]){
        //             // cout << str1[i+j] << endl;
        //             cnt++;
        //         }
        //         // cout << cnt << endl;
        //     }
        //     // cout << a.length() << endl;
        //     if(cnt==a.length()){
        //         // cout << a.length() << endl;
        //         ans++;
        //     }
        // }
    }
    string s2;
    istringstream sss(str1);
    while(sss>>s2){
        if(s2==a){
            count++;
        }
    }
    cout << count;
    return 0;
}

/*
#include<bits/stdc++.h>
using namespace std;
main(){
	string word,tence;
	getline(cin,word);
	getline(cin,tence);
	int count=0;
	
	for(int i=0;i<tence.length();i++){
		
		if(tence.substr(i,word.length())==word 
        and tence[i-1] <'A' 
        and ((int)tence[i+word.length()] < (int)'A' 
        or tence[i+word.length()] == NULL )){
			count++;
		}
	}
	cout<<count;
}
*/

/*
int main(){
    string a, str1;
    int cnt=0, ans=0;
    getline(cin, a);
    getline(cin, str1);
    for(int i=0;i<str1.length();i++){
        if(a[0]==str1[i]){
            cnt=0;
            for(int j=0;j<a.length();j++){
                if(a[j]==str1[i+j]){
                    // cout << str1[i+j] << endl;
                    cnt++;
                }
                // cout << cnt << endl;
            }
            // cout << a.length() << endl;
            if(cnt==a.length()){
                // cout << a.length() << endl;
                ans++;
            }
        }
    }
    cout << ans;
    return 0;
}

*/