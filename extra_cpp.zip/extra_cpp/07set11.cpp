#include<iostream>
#include<set>
using namespace std;
int main(){
    string a, b;
    multiset<char> s1, s2;
    getline(cin, a);
    getline(cin, b);
    for(char i:a){
        if(i==' ') continue;
        if(i>='A'&&i<='Z'){
            i = i+32;
        }
        s1.insert(i);

    }
    for(char i:b){
        if(i==' ') continue;
        if(i>='A'&&i<='Z'){
            i = i+32;
        }
        s2.insert(i);
    }

    if(s1==s2){
        cout << "YES";
    }else{
        cout << "NO";
    }
    return 0;
}