#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin >> n;
    string a;
    double b;
    map<string, double> m1;
    for(int i=0;i<n;i++){
        cin >> a >> b;
        m1[a] = b;
    }
    map<string, double> m2;
    int m;
    cin >> m;
    for(int i=0;i<m;i++){
        cin >> a >> b;
        // m2[a] = b;
        // auto itr = m1.begin();
        for(auto itr = m1.begin(); itr!=m1.end(); itr++){
            if((*itr).first==a){
                m2[a] = m2[a] + b;
            }
        }
    }
    for(auto itr = m1.begin(); itr !=m1.end();itr++){
        if(m2.find((*itr).first)!=m2.end()){
            // (*itr).second = (*itr).second * (m2[(*itr).first].second);

        }
        // for(auto itl = m2.begin(); itl !=m2.end();itl++){
        //     if((*itr).first == (*itl).first){
        //         (*itr).second =* (*itl).second;
        //     }
        //     if()
        // }
        
    }
    for(auto itr = m2.begin(); itr !=m2.end();itr++){
        cout << endl << (*itr).first << " " << (*itr).second << endl;

    }
    return 0;
}