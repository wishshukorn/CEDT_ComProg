#include<iostream>
using namespace std;
class test{
    public:
    test() : data() {
        cout << "created" << endl;
    }
    ~test() {
        cout << data << " destroyed" << endl;
    }
    int data;
};

int main(){
    test *a, *b;
    a = new test;
    a -> data = 10;
    cout << a -> data << endl; // dereference
    delete a;

    b = new test[4];
    b[0].data = 10;
    b[1].data = 20;
    b[2].data = 30;
    b[3].data = 40;
    delete [] b;
}

// memory leak: shared_ptr<T>