#include<iostream>
#include<vector>
using namespace std;

int n, k, len;
vector<int> dna;

bool isVi(int begin, int end, bool reverse){
    int level = end - begin;

    if(level == 2){
        if(!reverse){
            return dna[begin] == 0 && dna[begin+1] == 1;
        }else{
            return dna[begin + 1] == 0 && dna[begin] == 1;
        }
    }

        int mid = (begin + end) / 2;

        if(!reverse){
            return (isVi(begin, mid, false) || isVi(begin, mid, true)) && (isVi(mid, end, false));
        }else{
            return (isVi(begin, mid, true)) && (isVi(mid, end, true) || (isVi(mid, end, false)));
        }
    
}

void vi(){
    for(int i=0;i<len;i++){
        cin >> dna[i];
    }
    cout << (isVi(0, len, false) ? "yes" : "no") << "\n";
}

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0);
    cin >> n >> k;
    len = 1 << k;
    dna = vector<int>(len);

    for(int i=0;i<n;i++){
        vi();
    }

}