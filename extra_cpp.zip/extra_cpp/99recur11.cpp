#include <iostream> 
 
using namespace std;  
 
// string dec2hex(int d) { 
//     if(d<16) return (d == 0 ? "0" : d == 1 ? "1" : d == 2 ? "2": d == 3 ? "3" : d == 4 ? "4" : d == 5 ? "5" : d == 6 ? "6" : d == 7 ? "7" : d == 8 ? "8" : d == 9 ? "9" : d == 10 ? "A" : d == 11 ? "B" : d == 12 ? "C" : d == 13 ? "D" : d == 14 ? "E" : "F");
//     return dec2hex(d/16) + dec2hex(d%16);
// } 

string dec2hex(int d) {
    string a[] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"}; 
    if (d < 16) return a[d]; 
    return dec2hex(d/16) + dec2hex(d%16); 
} 

int main() { 
    int d; 
    while (cin >> d) { 
        cout << d << " -> " << dec2hex(d) << endl; 
    } 
    return 0; 
}