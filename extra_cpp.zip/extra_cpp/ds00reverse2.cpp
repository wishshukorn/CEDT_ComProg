#include <iostream>
 #include <vector>
 using namespace std;
//  void reverse(vector<int> &v,vector<int>::iterator a,vector<int>::iterator b) {
//   //write your code only in this function
//   int j=0;
//   for(auto i=a;i!=b-1;i++){
//     if(j==v.size()/2){
//         break;
//     }
//     int fak = *i;
//     *i = *(b-j);
//     *(b-j) = fak;
//     j++;

//   }
  
//  }

void reverse(vector<int> &v,vector<int>::iterator a,vector<int>::iterator b) {
  //write your code only in this function
  b--;
  while(a<b){
    swap(*a,*b);
    a++;
    b--;
  }
 }

 int main() {
  //read input
  int n,a,b;
  cin >> n;
  vector<int> v;
  for (int i = 0;i < n;i++) {
    int c;
    cin >> c;
    v.push_back(c);
  }
  cin >> a >> b;
  //call function
  reverse(v,v.begin()+a,v.begin()+b+1);
  //display content of the vector
  for (auto &x : v) {
    cout << x << " ";
  }
  cout << endl;
 }