#include<iostream>
#include<set>
using namespace std;
int main(){
    int a, i=0;
    bool is;
    set<int> s;
    while(cin >> a){
        i++;
        if(s.find(a)!=s.end()){
            is = true;
            break;
        }
        s.insert(a);
    }
    if(is){
        cout << i;
    }else{
        cout << -1;
    }
    return 0;
}