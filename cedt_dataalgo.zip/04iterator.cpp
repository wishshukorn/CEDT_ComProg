#include<iostream>
#include<vector>
#include<algorithm>
#include<string>
using namespace std;
int main(){
    vector<int> v1 = {3, 0, 1, 2, 4, -3, 9, 8};
    vector<float> v2 = {10.2, -4, 0.13, 3.14, 2.73};
    auto it1 = min_element(v1.begin(), v1.end());
    auto it2 = max_element(v2.begin()+2, v2.end());

    cout << *it1 << endl;
    cout << *it2 << endl;

    vector<string> s1 = {"somchai", "somying", "somsak"};
    for(string x : s1){
        cout << x << ", ";
    }
    cout << endl;
    for(auto &x : s1){
        x.replace(0, 4, "--");
    }
    for(auto &x : s1){
        cout << x << " ";
    }
    cout << endl;
    
    vector<int> v3 = {10, 20};
    auto it3 = v3.end()-1;
    v3.resize(10);
    cout << *it3 << endl;
    v3.insert(it3, 99);
    for(auto &x : v3){
        cout << x << " ";
    }

}