class huffman_tree{
    protected:
    class huffman_node{
        public:
            char letter;
            int freq;
            huffman_node *left, *right;
            huffman_node() : letter('*'), freq(0), left(NULL), right(NULL) {}
            huffman_node(char letter, int freq, huffman_node *)
    }
}