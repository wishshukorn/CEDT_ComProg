#include<iostream>
#include<cmath>
using namespace std;

long long POW (long long a, long long b){
    long long sum=1;
    for(long long i=0;i<b;i++){
        sum = sum * a;
    }
    return sum;
}

// long long MOD(long long a, long long b){
//     long long ans = a/b;
//     return ans = a-(b*(ans));
// }

long long PowerMod(long long a, long long k, long long m){
    // if(k%2==0) return MOD((POW((MOD(POW(a, k/2),m)),2)),m);
    // else return a*MOD((POW((MOD(POW(a, k/2),m)),2)),m);
    if(k==0) return 1;
    if(k%2==0) return POW((PowerMod(a, (k/2), m)), 2)%m;
    else return a*POW((PowerMod(a, (k/2), m)), 2)%m;
}

int main(){
    long long a, k, m;
    cin >> a >> k >> m;
    cout << PowerMod(a, k, m);
    return 0;
}