#include<iostream>
#include<tuple>
using namespace std;
int main(){
    int n,a,stt;
    string s;
    cin >> n;
    tuple<int, string> t1[n];
    for(int i=0;i<n;i++){
        cin >> s >> a;
        t1[i] = make_tuple(a, s);
    }
    cin >> stt;
    int j=0;
    for(auto i:t1){
        if(j==stt){
            break;
        }
        cout << ge
    }
}