#ifndef __STUDENT_H__
#define __STUDENT_H__

#include <algorithm>
#include <vector>
#include<set>
#include "priority_queue.h"

template <typename T,typename Comp >
T CP::priority_queue<T,Comp>::get_kth(size_t k) const {
  //write your code here
  //can include anything
  // for(i=0;i<k-1;i++){
  //   pop();
  // }
  // if(mLess(mData[0], mData[1])){
  //   return mData[mSize-k];
  // }else{
  //   return mData[k-1];
  // }
  // CP::priority_queue<T, Comparator> pq_copy = *this;
  // if(mData[0]>0){
  //   return mData[k-1];
  // }else{
  //   return mData[mSize-k];

  // }

    
  //   // สลับค่าจาก priority_queue ตามจำนวน k ครั้ง
  //    priority_queue<T, Comp> pq_copy = *this;

  //   // Pop elements k times from pq_copy and return the k-th popped element
  //   T result;
  //   for (size_t i = 1; i <= k; ++i) {
  //       result = pq_copy.top();  // Get the top element
  //       pq_copy.pop();           // Remove the top element
  //   }

  //   // Return the k-th element
  //   return result;
  if(k==1){
    return mData[0];
  }else if(k==2){
    if(mLess(mData[1], mData[2])){
      return mData[2];
    }else{
      return mData[1];
    }
  }else{
    T t;
    if(mLess(mData[1], mData[2])){
      t = mData[1];
    }else{
      t = mData[2];
    }

    for(int i=3;i<=6;i++){
      if(mLess(t, mData[i])){
        t = mData[i];
      }
    }

    return t;


    // int m = std::min(mSize, (size_t) 8);
    //  std::vector<T> v;
    //       for(int i = 0 ; i < m ; i++)v.push_back(mData[i]); 
    //       std::sort(v.begin(),v.end(), mLess);
    //       return *(v.end()-k);
    //   std::set<T> s;
    //   for(int i = 0 ; i < m ; i++){
    //     s.insert(mData[i]);
    //   }
    // return *(s.end()-k);
  }
}

#endif
