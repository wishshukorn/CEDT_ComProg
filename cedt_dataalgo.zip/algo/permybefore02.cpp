#include<iostream>
#include<vector>
#include<map>
using namespace std;

void perm(int n, vector<int> &sol, int len, vector<bool> &used, map<int, int> tor){
    if(len==n){
        for(auto &x : sol){
            cout << x << " ";
        }
        cout << "\n";
        return;
    }
    
    for(int i=0;i<n;i++){
        if(used[i] == false && (!tor.count(i) || !used[tor.at(i)])){
            used[i] = true;
            sol[len] = i;
            perm(n, sol, len+1, used, tor);
            used[i] = false;
        }
    }
    
        
    
}

int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    int n, m;
    int a, b;
    cin >> n >> m;
    
    map<int, int> tor;
    vector<int> v(n);
    vector<bool> chk={false};
    for(int i=0;i<m;i++){
        cin >> a >> b;
        tor[a] = b;
    }
    perm(n,v,0,chk,tor);
}