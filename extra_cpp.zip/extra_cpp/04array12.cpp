#include<iostream>
using namespace std;
int main(){
    string real[10]={"Robert", "William", "James", "John", "Margaret", "Edward", "Sarah", "Andrew", "Anthony", "Deborah"};
    string nick[]={"Dick", "Bill", "Jim", "Jack", "Peggy", "Ed", "Sally", "Andy", "Tony", "Debbie"};
    
    int num;
    cin >> num;
    cin.ignore();

    for(int i=0;i<num;i++){
        bool check=true;
        string a;
        getline(cin, a);

        for(int j=0;j<10;j++){
            
            if(a==real[j]){
                cout << nick[j] << endl;
                check=false;
                // break;
            }else if(a==nick[j]){
                cout << real[j] << endl;
                check=false;
                // break;
            }
            // else if(a!=nick[j]&&a!=real[j]){
            //     cout << "Not found" << endl;
            //     break;
            // }
        }

        if(check){
            cout << "Not found" << endl;
        }
        
    }
}