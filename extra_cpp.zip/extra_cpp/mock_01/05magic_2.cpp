#include<iostream>
using namespace std;
int main(){
    int n, cnt=0;
    cin >> n;
    int a[n], b[n]={0};
    for(int i=0;i<n;i++){
        cin >> a[i];
    }
    
    for(int i=0;i<n;i++){
        b[n]={0};
        // int tem = a[i];
        int j=i+1;
        int k=0;
        b[0] = a[i];

        while(a[j] != a[i] && j != n){
            cout << "Hello ";
            b[k+1] = a[j];
            j++;
            k++;
        }

        for(int u:b){
            cout << u << " ";
        }
        cout << endl;
        
    }
}