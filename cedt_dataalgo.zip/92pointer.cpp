#include<iostream>
using namespace std;
// int main(){
//     int x, y;
//     int *a;
//     int *b;

//     x = 10;
//     a = &x;
//     b = a;
//     *b = 30;
//     y = *b;
//     int z = *a;

//     cout << &x << endl << &y << endl << &a << endl << &b << endl << &z << endl;
//     cout << x << endl << y << endl << *a << endl << *b << endl << z << endl;
//     cout << sizeof(int) << endl << sizeof(int*) << endl;
//     return 0;
// }

int main(){
    int x, y, z;
    x = 1; y = 2, z = 3;
    int *a, *b;

    a = &x;
    b = a + 2;

    cout << &x << endl << &y << endl << &z << endl;
    cout << a << endl << b << endl; // *sizeof
    cout << b-a << endl; // /sizeof
}