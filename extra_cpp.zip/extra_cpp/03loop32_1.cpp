#include<iostream>
#include<vector>
using namespace std;
int main(){
    int num;
    cin >> num;
    cin.ignore();
    vector<string> a;
    string str;
    for(int i=0;i<num;i++){
        getline(cin, str);
        a.push_back(str);
    }
    for(int i=0;i<num;i++){
        for(int j=0;a[i][j]!='R';j++){
            cout << a[i][j] << endl;
        }
    }
}