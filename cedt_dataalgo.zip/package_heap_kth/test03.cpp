#ifndef __STUDENT_H__
#define __STUDENT_H__

#include <algorithm>
#include <vector>
#include "priority_queue.h"

template <typename T,typename Comp >
T CP::priority_queue<T,Comp>::get_kth(size_t k) const {
  if(k==1){
    return mData[0];
  }else if(k==2){
    if(mLess(mData[1], mLess[2])){
      return mData[2];
    }else{
      return mData[1];
    }
  }else if(k==3){
    int m = std::min(mSize, (size_t) 8);
    std::vector<T> v;
          for(int i = 0 ; i < m ; i++)v.push_back(mData[i]); 
          std::sort(v.begin(),v.end(), mLess);
          return *(v.end()-k);
      // std::set<T> s;
      // for(int i = 0 ; i < m ; i++){
      //   s.insert(mData[i]);
      // }
    // return *(s.end()-k);
  }
}

#endif
