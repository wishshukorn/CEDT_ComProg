#include<iostream>
#include<cmath>
using namespace std;
int main(){
    string a, b;
    cin >> a >> b;
    int num = b.length()-a.length();
    int minn = min(b.length(), a.length());
    int cnt = 0;
    int maxx = -2e9;
    int maxx_index = 0;

    for(int i=0;i<abs(num);i++){
        cnt = 0;
        for(int j=0;j<minn;j++){
            if(a[j]==b[j+i]){
                cnt++;
            }
        }
        // minn--;
        if(cnt > maxx){
            maxx = cnt;
            maxx_index = i;
        }
    }
    // cout << maxx << endl << maxx_index << endl;
    for(int i=0;i<maxx_index;i++){
        cout << "-";
    }
    cout << a << endl << b << endl << maxx;
}