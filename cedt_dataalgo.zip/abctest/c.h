#include "a.h"
class c{
    a y;
};