#include<iostream>
#include<utility>
#include<set>
using namespace std;
int main(){
    std::ios_base::sync_with_stdio(false); std::cin.tie(0);
    int n, m;
    cin >> n >> m;
    set<pair<int, int>> a;
    int b, c;
    for(int i=0;i<n;i++){
        cin >> b >> c;
        a.insert(make_pair(b, c));
    }
    for(int i=0;i<m;i++){
        cin >> b;
        int ans = 0;
        
        for(auto j:a){
            if(b<=0){
                break;
            }
            b = b-j.second;
            ans = j.first;
            
        }
        cout << ans << endl;
    }
}