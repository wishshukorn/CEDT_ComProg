#include<bits/stdc++.h>
using namespace std;
int main(){
    string a;
    // cin >> a;
    // long long b = a - '0';
    // long long b = stoll(a);
    // long long b = a[0] - '0';
    // for(int i=1;i<a.length();i++){
    //     b = (b*10) + a[i];
    // }
    long long sum = 0;
    // sum = sum + b;
    while(cin >> a){
        if(a=="END"){
            break;
        }
        long long b = stoll(a);
        sum = sum + b;
    }
    cout << sum;
    return 0;
}