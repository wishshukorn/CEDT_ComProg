#include<iostream>

template<typename T, typename Comp = std::less<T>>
class priority_queue{
    protected:
        T *mData;
        size_t mCap;
        size_t mSize;
        Comp mLess;
    public:
        priority_queue(const Comp & c = Comp()):
            mData(new T[1]()),
            mCap(1),
            mSize(0),
            mLess(c)
        {}
        priority_queue(priority_queue<T, Comp> & a):
            mData(new T[a.mCap]()),
            mCap(a.mCap),
            mSize(a.mSize),
            mLess(a.mLess)
        {
            for(size_t i=0;i<a.mCap;i++){
                mData[i] = a.mData[i];
            }
        }
        ~priority_queue(){
            delete [] mData;
        }
        priority_queue<T, Comp> & operator=(priority_queue<T, Comp> other){
            using std::swap;
            swap(mSize, other.mSize);
            swap(mCap, other.mCap);
            swap(mData, other.mData);
            swap(mLess, other.mLess);
            return *this;
        }
        void push(const T & element){
            if(mSize + 1 > mCap){
                expand(mCap*2);
            }
            mData[mSize] = element;
            mSize++;
            fixUp(mSize-1);
        }
        void expand(size_t capacity){
            T *arr = new T[capacity]();
            for(size_t i=0;i<mSize;i++){
                arr[i] = mData[i];
            }
            delete [] mData;
            mData = arr;
            mCap = capacity;
        }


};
