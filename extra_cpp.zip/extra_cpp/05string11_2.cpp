#include<iostream>
using namespace std;
int main(){
    string a;
    while(getline(cin, a)){
        string b="";
        int i=0;
        int j=0;
        char ch;
        while(a[j]!='\0'){
            if(((a[j]>=33&&a[j]<=47)||(a[j]>=58&&a[j]<=64)||(a[j]>=91&&a[j]<=96)||(a[j]>=123&&a[j]<=126))&&((a[j+1]>=65&&a[j+1]<=90)||(a[j+1]>=97&&a[j+1]<=122))&&a[j]!=39){
                ch = a[j];
                break;
            }
            j++;
        }
        // cout << ch << endl;
        while(a[i]!='\0'){
            if(a[i]==ch&&a[i+1]!='\0'){
                // char pap = a[i];
                i++;
                while(a[i]!=ch&&a[i+1]!='\0'){
                    b = b + a[i];
                    i++;
                }
            }
        i++;
        }
    cout << b << endl;
    }
    
}