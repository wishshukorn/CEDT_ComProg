#include<iostream>
#include<vector>
using namespace std;

void perm(int n, vector<int> &sol, int len, vector<bool> &used){
    if(len<n){
        for(int i=0;i<n;i++){
            if(used[i] == false){
                used[i] = true;
                sol[len] = i;
                perm(n, sol, len+1, used);
                used[i] = false;
            }
        }
    }else{
        for(auto &x : sol){
            cout << x << " ";
        }
        cout << endl;
    }
}

int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    int n, m;
    cin >> n >> m;
    int a[n];
    vector<int> v(n);
    vector<bool> b={false};
    for(int i=0;i<m;i++){
        cin >> a[i];
    }
    perm(n,v,0,b);
}