#include<algorithm>
#include<iostream>
#include<vector>

// slowed

int GCD(int A, int B){
    int ans = 1;
    for(int i=2;i<std::min(A, B);i++){
        if(A%i == 0 && B%i == 0){
            ans = i;
        }
    }
    return ans;
}

int fibo(int n){
    if(n==0){
        return 0;
    }
    if(n==1){
        return 1;
    }
    return fibo(n-1)+fibo(n-2);
}

std::vector<std::vector<int>> matrix_expo(const std::vector<std::vector<int>> & A, int exp){
    if(exp == 1){
        return A;
    }
    std::vector<std::vector<int>> half = matrix_expo(A, exp/2);
    if(exp%2 == 0){
        return multiply(half, half);
    }else{
        return multiply(multiply(half, half), A);
    }
}

int fibonacci(int n){
    if(n==0){
        return 0;
    }
    if(n==1){
        return 1;
    }
    std::vector<std::vector<int>> base = {{1, 1}, {1, 0}};
    std::vector<std::vector<int>> result = matrix_expo(base, n-1);
    return result[0][0]
}

int main(){
    int n;
    std::cin >> n;
    std::vector<int> v(n+1);
    v[0] = 0;
    v[1] = 1;
    for(int i=2;i<=n;i++){
        v[i] = v[i-1] + v[i-2];
    }

}