# def combination(N, sol):
#     if sol.length < N
#         sol_a = sol + [0]
#         combination(N, sol_a)
#         sol_b = sol + [1]
#         combination(N, sol_b)
#     else
#         print(sol)
    

    