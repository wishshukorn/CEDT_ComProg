#include<iostream>
using namespace std;
int main(){
    int cnt = 0;
    for(int i=100;i<1000;i++){
        if(i/100==i%10){
            cnt++;
        }
    }
    cout << cnt;
    return 0;
}