#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int main(int argc, char const *argv[])
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    unsigned r, c;
    cin >> r >> c;
    vector<vector<bool>> visited(r, vector<bool>(c));
    vector<vector<bool>> target(r, vector<bool>(c));
    queue<pair<unsigned, unsigned>> queue;
    for (unsigned i = 0; i < r; i++)
        for (unsigned j = 0; j < c; j++)
        {
            char input;
            cin >> input;
            switch (input)
            {
            case '1':
                queue.push({i, j});
                visited[i][j] = true;
                break;
            case '2':
                target[i][j] = true;
                break;
            case '3':
                visited[i][j] = true;
                break;
            }
        }

    unsigned prevNode = queue.size();
    unsigned count = 0;
    bool notFound = true;
    while (!queue.empty() && notFound)
    {
        unsigned newNode = 0;
        for (unsigned i = 0; i < prevNode; i++)
        {
            unsigned row = queue.front().first;
            unsigned col = queue.front().second;
            queue.pop();
            if (target[row][col])
            {
                notFound = false;
                break;
            }
            if (row && !visited[row - 1][col] && ++newNode)
            {
                visited[row - 1][col] = true;
                queue.push({row - 1, col});
            }
            if (row + 1 != r && !visited[row + 1][col] && ++newNode)
            {
                visited[row + 1][col] = true;
                queue.push({row + 1, col});
            }
            if (col && !visited[row][col - 1] && ++newNode)
            {
                visited[row][col - 1] = true;
                queue.push({row, col - 1});
            }
            if (col + 1 != c && !visited[row][col + 1] && ++newNode)
            {
                visited[row][col + 1] = true;
                queue.push({row, col + 1});
            }
        }
        prevNode = newNode;
        count++;
    }

    cout << count;
    return 0;
}

