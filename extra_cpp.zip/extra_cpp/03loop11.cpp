#include<iostream>
#include<cmath>
using namespace std;
int main(){
    double n, sum=0, cnt=0;
    cin >> n;
    if(n == -1){
        cout << "No Data";
        return 0;
    }
    while(n>=0){
        sum = sum + n;
        cnt++;
        cin >> n;
    }
    cout << round((sum/cnt)*100)/100;
    return 0;
}