#include<iostream>
using namespace std;

int lap(int a[], int b[], int n){
    
}

int main(){
    int n;
    cin >> n;
    int a[n][n];
    int b[((n-1)*n)/2]={0};
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cin >> a[i][j];
        }
    }
    int k=0;
    for(int i=0;i<n;i++){
        for(int j=i;j<n;j++){
            b[k] = lap(a[i], a[j], n);
            k++;
        }
    }
}