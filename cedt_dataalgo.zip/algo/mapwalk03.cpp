#include<iostream>
#include<vector>
using namespace std;

int n, m;

void mw(int row, int col, vector<vector<int>>& a, string& s){
    a[row][col] = 1;
    if(row == n-1 && col == m-1){
        cout << s << endl;
        return;
    }
    if(col + 1 < m && a[row][col + 1] == 0){
        s = s + "A";
        mw(row, col + 1, a, s);
        s.pop_back();
        a[row][col + 1] = 0;
    }

    if(row + 1 < n && a[row + 1][col] == 0){
        s = s + "B";
        mw(row + 1, col, a, s);
        s.pop_back();
        a[row + 1][col] = 0;
    }
    
    if(row - 1 >= 0 && a[row - 1][col] == 0){
        s = s + "C";
        mw(row - 1, col, a, s);
        s.pop_back();
        a[row - 1][col] = 0;
    }
}

int main(){
    cin >> n >> m;
    string s = "";
    vector<vector<int>> a(n, vector<int>(m));
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin >> a[i][j];
        }
    }
    mw(0, 0, a, s);
    cout << "DONE" << endl;
}