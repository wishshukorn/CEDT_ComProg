#include<iostream>

template <typename T>
class vector{
    protected:
        T *mData;
        size_t mCap;
        size_t mSize;
        void rangeCheck(int n){
            if(n<0 || (size_t)n >= mSize){
                throw std::out_of_range("index of out range");
            }
        }
        void expand(size_t capacity){
            T *arr = new T[capacity]();
            for(size_t i=0;i<mSize;i++){
                arr[i] = mData[i];
            }
            delete [] mData;
            mData = arr;
            mCap = capacity;
        }
        void ensureCapacity(size_t capacity){
            if(capacity>mCap){
                size_t s = (capacity > 2*mCap) ? capacity : 2*mCap;
                expand(s);
            }
        }
        bool empty() const{
            return mSize == 0;
        }
        size_t size() const{
            return mSize;
        }
        size_t capacity() const{
            return mCap;
        }
    public:
        vector(){
            int cap = 1;
            mData = new T[cap]();
            mCap = cap;
            mSize = 0;
        }
        vector(size_t cap){
            mData = new T[cap]();
            mCap = cap;
            mSize = cap;
        }
        ~vector(){
            delete [] mData;
        }
        T& at(int index){
            rangeCheck(index);
            return mData[index];
        }
        T& operator[](int index){
            return mData[index];
        }
        void push_back(const T* element){
            ensureCapacity(mSize+1);
            mData[mSize++] = element;
        }
        void push_back(const T* element){
            inset(end(), element);
        }
        void pop_back(){
            mSize--;
        }
        vector(const vector<T> &a){
            mData = new T[a.capacity()]();
            mCap = a.capacity();
            mSize = a.size();
            for(size_t i=0;i<a.size();i++){
                mData[i] = a[i];
            }
        }
        vector<T>& operator=(vector<T> &other){
            if(mData != other.mData){
                delete [] mData;
                mData = new T[other.capacity()]();
                mCap = other.capacity();
                mSize = other.size();
                for(size_t i=0;i<other.size();i++){
                    mData[i] = other[i];
                }
            }
        }
        vector<T>& operator=(vector<T> other){
            using std::swap;
            swap(this->mSize, other.mSize);
            swap(this->mCap, other.mCap);
            swap(this->mData, other.mData);
            return *this;
        }
        typedef T* iterator;
        iterator begin(){
            return &mData[0]; // mData
        }
        iterator end(){
            return begin()+mSize;
        }
        iterator insert(iterator it, const T& element){
            size_t pos = it - begin();
            ensureCapacity(mSize + 1);
            for(size_t i=mSize;i>pos;i--){
                mData[i] = mData[i-1];
            }
            mData[pos] = element;
            mSize++;
            return begin()+pos;
        }
        void erase(iterator it){
            while((it+1)!=end()){
                *it = *(it+1);
                it++;
            }
            mSize--;
        }

};

int main(){
    vector<int> w(5);
    for(int i=0;i<5;i++){
        w[i] = i*10;
    }
    vector<int> x(w);
    vector<int> y = w;
    x[3] = -1;
    std::cout << y[3] << std::endl << w[3] << std::endl;
}