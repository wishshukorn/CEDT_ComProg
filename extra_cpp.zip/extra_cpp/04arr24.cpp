#include<bits/stdc++.h>
using namespace std;

int MAXX(int arr[], int sizee){
    int gi = -2e9;
    int num;
    for(int i=0;i<sizee;i++){
        if(arr[i]>gi){
            gi = arr[i];
            num = i;
        }
    }
    return num;
}

int main(){
    int n;
    cin >> n;
    int a[n], b[n];
    for(int i=0;i<n;i++){
        cin >> a[i];
    }
    // int maxx = *max_element(a, a+n);

    // cout << MAXX(a, n);
    // b[0] = maxx;
    // for(int i=0;i<n;i++){
    //     b[i+1] = 
    // }

    // b[0] = *max_element(a, a+n);
    // cout << b[0] << " ";
    // a[MAXX(a, n)] = 0;
    swap(a[0], a[MAXX(a, n)]);
    for(int i=0;i<n;i++){
        cout << a[i] << " ";
    }
    cout << endl;
    for(int i=0;i<n/2;i++){
        swap(a[i], a[n-i-1]);
    }
    for(int i=0;i<n;i++){
        cout << a[i] << " ";
    }

}