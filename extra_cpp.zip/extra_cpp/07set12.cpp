#include<iostream>
#include<set>
using namespace std;
int main(){
    bool is=false;
    int a, b = -1, i=0, num;
    set<int> s;
    while(cin >> a){
        if(s.find(a)==s.end()){
            if(is){
                continue;
            }
            is = true;
            b = a;
            num = i;
        }
        i++;
    }
    if(is){
        cout << num;
    }else{
        cout << b;
    }
}