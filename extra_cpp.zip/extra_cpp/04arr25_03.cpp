#include<iostream>
using namespace std;
int main(){
    int n, ans = 0;
    cin >> n;
    int a[n];
    int l[n], r[n];
    cin >> a[0];
    l[0] = a[0];
    // r[0] = a[0];
    for(int i=1;i<n;i++){
        cin >> a[i];
        if(a[i]>l[i-1]){
            l[i] = a[i];
        }else{
            l[i] = l[i-1];
        }
    }
    r[n-1] = a[n-1];
    for(int i=n-2;i>=0;i--){
        if(a[i] > r[i+1]){
            r[i] = a[i];
        }else{
            r[i] = r[i+1];
        }
    }
    // cout << "l: ";
    // for(int i=0;i<n;i++){
    //     cout << l[i] << " ";
    // }
    // cout << endl << "r: ";
    // for(int i=0;i<n;i++){
    //     cout << r[i] << " ";
    // }
    for(int i=1;i<n-1;i++){
        ans = ans + (min(l[i], r[i]) - a[i]);
    }
    cout << ans;
    return 0;
}