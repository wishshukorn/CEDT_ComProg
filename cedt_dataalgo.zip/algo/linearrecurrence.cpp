#include<iostream>
#include<vector>
using namespace std;

int k, n;
vector<int> c;
vector<int> a;
int sum = 0;

int R(int n){
    if(n < k){
        return a[n];
    }
    for(int i=0;i<k;i++){
        sum = sum + (c[i] * R(n - i - 1));
    }
    return sum;
}

int main(){
    cin >> k >> n;
    c = vector<int>(k);
    a = vector<int>(k);
    for(int i=0;i<k;i++){
        cin >> c[i];
    }
    for(int i=0;i<k;i++){
        cin >> a[i];
    }
    cout << (R(n) % 32717);
}