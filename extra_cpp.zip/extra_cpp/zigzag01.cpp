#include<iostream>
using namespace std;
int main(){
    int n;
    cin >> n;
    double a[n], b[n];
    double ma, mb;
    for(int i=0;i<n;i++){
        cin >> a[i] >> b[i];
    }
    string ss;
    cin >> ss;
    if(ss=="Zig-Zag"){
        ma = a[0];
        mb = b[0];
        for(int i=0;i<n;i=i+2){
            ma = min(ma, a[i]);
            mb = max(mb, b[i]);
        }
        for(int i=1;i<n;i=i+2){
            ma = min(ma, b[i]);
            mb = max(mb, a[i]);
        }
        cout << ma << " " << mb;
    }else if(ss=="Zag-Zig"){
        ma = a[0];
        mb = b[0];
        for(int i=0;i<n;i=i+2){
            ma = max(ma, a[i]);
            mb = min(mb, b[i]);
        }
        for(int i=1;i<n;i=i+2){
            ma = max(ma, b[i]);
            mb = min(mb, a[i]);
        }
        cout << mb << " " << ma;
    }
}