#include <iostream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

typedef pair<int, int> edge; // cost, node

int main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr);
    
    int N;
    cin >> N;

    vector<vector<int>> w(N, vector<int>(N));
    
    for (int i = 0; i < N - 1; i++) {
        for (int j = i + 1; j < N; j++) {
            cin >> w[i][j];  
            w[j][i] = w[i][j];  
        }
    }

    int total_cost = 0, cnt = 0;

    priority_queue<edge, vector<edge>, greater<edge>> H;
    vector<int> costs(N, INT_MAX);
    vector<bool> taken(N, false);

    H.push({0, 0}); 

    while (!H.empty()) {
        auto [cost, node] = H.top();
        H.pop();

        if (taken[node]) continue;

        taken[node] = true;
        total_cost += cost;
        cnt++;

        if (cnt == N) {
            cout << total_cost;
            return 0;
        }

        for (int neighbor = 0; neighbor < N; neighbor++) {
            if (!taken[neighbor] && costs[neighbor] > w[node][neighbor]) {
                costs[neighbor] = w[node][neighbor];
                H.push({w[node][neighbor], neighbor});
            }
        }
    }
}


