#include <iostream>
#include <set>

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;

    set<pair<int, int>> publications;

    // Input the publication dates
    for (int i = 0; i < n; i++) {
        int year, month;
        cin >> year >> month;
        publications.insert({year, month});
    }

    bool first = true;

    // Process each query
    for (int i = 0; i < m; i++) {
        int queryYear, queryMonth;
        cin >> queryYear >> queryMonth;

        // Find the publication just before the queried date using upper_bound
        auto it = publications.upper_bound({queryYear, queryMonth});

        if (it == publications.begin()) {
            // No valid prior publication
            if (!first) cout << " ";
            cout << "-1 -1";
        } else {
            // Move one step back to get the most recent publication before the query
            --it;
            if (!first) cout << " ";
            cout << it->first << " " << it->second;
        }
        first = false;
    }

    cout << endl;
    return 0;
}
