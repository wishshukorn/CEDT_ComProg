#include<iostream>
#include<string>
using namespace std;
int main(){
    string student1, student2;
    double gpax1, gpax2;
    char com1, com2;
    char first_cal1, first_cal2;
    char sec_cal1, sec_cal2;
    cin >> student1 >> gpax1 >> com1 >> first_cal1 >> sec_cal1;
    cin >> student2 >> gpax2 >> com2 >> first_cal2 >> sec_cal2;
    if((com1>'A'||first_cal1>'C'||sec_cal1>'C')&&(com2>'A'||first_cal2>'C'||sec_cal2>'C')){
        cout << "None";
    }else if((com1=='A'||first_cal1<='C'||sec_cal1<='C')){
        cout << student1;

    }else if(com2=='A'||first_cal2<='C'||sec_cal2<='C'){
        cout << student2;
    }
    //&&first_cal1>'C'&&first_cal2>'C'&&sec_cal1>'C'&&sec_cal2>'C'
}