#ifndef A_H
#define A_H
class a{
    int m1, m2;
};
#endif