#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int main(){
    double x, re;
    cin >> x;
    // cout << tan;
    // re = (sqrt((x*x)+pow(cos(x*M_PI/180),2))) / (sin(x*M_PI/180) + ((pow(cos(x*M_PI/180), 3) / (x*x+1) )) );
    re = (sqrt((x*x)+(cos(x*M_PI/180)*cos(x*M_PI/180)))) / (sin(x*M_PI/180) + ((pow(cos(x*M_PI/180), 3) / (x*x+1) )) );

    cout << fixed << setprecision(1) << re;

}