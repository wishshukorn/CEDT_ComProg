#include<iostream>
using namespace std;
int main(){
    string a;
    getline(cin, a);
    for(int i=0;i<a.length();i++){
        if(a[i]=='('){
            a[i] = '[';
        }
        else if(a[i]=='['){
            a[i] = '(';
        }
        if(a[i]==')'){
            a[i] = ']';
        }
        else if(a[i]==']'){
            a[i] = ')';
        }
    }
    cout << a;
    return 0;
}