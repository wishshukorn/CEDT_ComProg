#include<iostream>
#include<map>
#include<set>
using namespace std;

int main(){
    set<pair<int, string>> s;
    int n, k;
    string a;
    cin >> n >> k;
    while(n--){
        cin >> a;
        
    }

}