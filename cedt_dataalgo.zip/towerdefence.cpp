#include<iostream>
using namespace std;
int main(){
    int n, m, k, w;
    cin >> n >> m >> k >> w;
    int p[m], h[m], t[k];
    int blk[n+1] = {0};
    int ans = 0;
    for(int i=0;i<m;i++){
        cin >> p[i];
    }
    for(int i=0;i<m;i++){
        cin >> h[i];
        blk[p[i]] = h[i];
    }
    for(int i=0;i<k;i++){
        cin >> t[i];
        int a = t[i]-w;
        if(t[i]-w<0){
            a=0;
        }
        for(int j=a;j<=t[i]+w;j++){
            if(blk[j]>0){
                blk[j] = blk[j] - 1;
                break;
            }
            blk[j] = blk[j]-1;
        }
    }
    for(int i=0;i<n+1;i++){
        if(blk[i]<=0){
            continue;
        }
        ans = ans + blk[i];
        // cout << blk[i] << " ";
    }
    cout << ans;
    return 0;
}