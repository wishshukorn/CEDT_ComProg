#include<iostream>
#include<vector>
using namespace std;

int find_max(vector<int> v){
    int m = v[0];
    for(size_t i=0;i<v.size();i++){
        if(v[i]>m){
            m = v[i];
        }
    }
    return m;
}

int count_pair_sum(vector<int> v, int k){
    int count = 0;
    for(size_t i=0;i<v.size();i++){
        for(size_t j=0;j<v.size();j++){
            if(i!=j && v[i]+v[j]==k){
                count++;
            }
        }
    }
    return count/2;
}

template<typename T>
class test{
    T* mData;
    size_t mCap;
    size_t mSize;
    public:
        typedef T* iterator;
};

bool find(iterator a, iterator b, T value){
    while(a<b){
        if(*a == value){
            return true;
        }
        a++;
    }
    return false;

}

size_t count(iterator first, iterator last, const T& value){
    size_t ret = 0;
    for(; first!=last;++first){
        if(*first == value){
            ret++;
        }
    }
}

void erase(iterator it){
    while((it+1)!=end()){
        *it = *(it+1);
        it++;
    }
    mSize--;
}

int test1(vector<int> v){
    int sum = 0;
    for(auto &x : v){
        sum += x;
    }
    return sum;
}