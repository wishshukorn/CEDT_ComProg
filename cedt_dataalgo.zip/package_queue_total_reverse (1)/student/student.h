#ifndef _STUDENT_H_INCLUDED
#define _STUDENT_H_INCLUDED
#include "queue.h"

#include<stack>

template <typename T>
void CP::queue<T>::reverse() {
  // Your code here
  // int n = size();
  // while(n--){
  //   std::cout << back() << " ";
  //   mSize--;
  // }
  // for(int i=0;i<n/2;i++){
  //   std::swap(mData[i], mData[size()-i-1]);
  // }
  std::stack<T> s;
  while(!empty()){
    s.push(front());
    pop();
  }
  while(!(s.empty())){
    push(s.top());
    pop();
  }

  
}

template <typename T>
const T& CP::queue<T>::front() const {
  // You MAY need to edit this function
  return mData[mFront];
}

template <typename T>
const T& CP::queue<T>::back() const {
  // You MAY need to edit this function
  return mData[(mFront + mSize - 1) % mCap];
}

template <typename T>
void CP::queue<T>::push(const T& element) {
  // You MAY need to edit this function
  ensureCapacity(mSize + 1);
  mData[(mFront + mSize) % mCap] = element;
  mSize++;
}

template <typename T>
void CP::queue<T>::pop() {
  // You MAY need to edit this function
  mFront = (mFront + 1) % mCap;
  mSize--;
}

#endif