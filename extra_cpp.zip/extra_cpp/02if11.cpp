#include<iostream>
using namespace std;
int main(){
    int a, b, c, d, e, sw;
    cin >> a >> b >> c >> d >> e;
    if(a>b){
        sw = a;
        a = b;
        b = sw;
    }
    if(c>d){
        sw = c;
        c = d;
        d = sw;
    }
    if(a>c){
        sw = b;
        b = d;
        d = sw;
        c = a;
    }
    a = e;
    if(a>b){
        sw = a;
        a = b;
        b = sw;
    }
    if(c>a){
        sw = b;
        b = d;
        d = sw;
        a = c;
    }
    if(a>d){
        cout << d;
    }else{
        cout << a;
    }
    return 0;
}