template<typename T>
vector<T> selection_sort(vector<T> A){
    vector<T> B;
    while(A.size() > 0){
        auto it = max_element(A.begin(), A.end());
        B.insert(B.begin(), *it);
        A.erase(it);
    }
    return B;
}

//better
vector<T> selection_sort_2(vector<T> A){
    vector<T> B(A.size());
    while(A.size() > 0){
        auto it = max_element(A.begin(), A.end());
        B[A.size()-1] = *it;
        swap(*it, A[A.size()-1]);
        A.pop_back;
    }
    return B;
}

void selection_sort_final(vector<T> &A){
    size_t pos = A.size() - 1;
    for(; pos>0;pos--){
        int max_idx = 0;
        for(size_t i=0;i<=pos;i++){
            if(A[i] > A[max_idx]){
                max_idx = i;
            }
        }
        swap(A[target_pos], A[max_idx]);
    }
}

void insertion_sort(vector<T> &A){
    for(int pos = A.size()-2;pos>=0;pos--){
        T tmp = A[pos];
        size_t i = pos+1;
        while(i<A.size() && A[i]<tmp){
            A[i-1] = A[i];
            i++;
        }
        A[i-1] = tmp;
    }
}

template<typename T>
int bsearch(vector<T> &v, T k, int start, int stop){
    if(start == stop){
        return v[start]==k ? start : -1;
    }
    int m = (start+stop) >> 1;
    if(v[m] >= k){
        return bsearch(v, k, start, m)
    }
    return bsearch(v, k, m+1, stop)
}