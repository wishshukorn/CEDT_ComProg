#include <iostream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

const int MAXN = 2001;

void solve() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m;
    cin >> n >> m;
    
    int ci[MAXN];
    for (int i = 0; i < n; i++) {
        cin >> ci[i];
    }
    
    int co[MAXN];
    for (int i = 0; i < n; i++) {
        cin >> co[i];
    }
    
    vector<vector<int>> graph(n);
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        graph[a].push_back(b);
    }
    
    int dist[MAXN];
    fill(dist, dist + n, INT_MAX);
    dist[0] = 0;
    
    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> pq;
    pq.push({0, 0});
    
    while (!pq.empty()) {
        int cost = pq.top().first;
        int curr = pq.top().second;
        pq.pop();
        
        if (cost > dist[curr]) continue;
        
        for (int next : graph[curr]) {
            int new_cost = cost + co[curr] + ci[next];
            
            if (new_cost < dist[next]) {
                dist[next] = new_cost;
                pq.push({new_cost, next});
            }
        }
    }
    
    for (int i = 0; i < n; i++) {
        cout << (dist[i] == INT_MAX ? -1 : dist[i]) << " ";
    }
    cout << "\n";
}

int main() {
    solve();
}
