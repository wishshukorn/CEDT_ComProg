#include<iostream>
using namespace std;
int main(){
    string a;
    string ch = "abcdefghijklmnopqrstuvwxyz";
    getline(cin, a);
    int num[26]={0};
    for(int i=0;i<a.length();i++){
        if(a[i]>='A'&&a[i]<='Z'){ // isalpha(a[i])
            a[i] = a[i] + 32;
        }
        // cout << a[i] << endl;
        for(int j=0;j<ch.length();j++){
            if(a[i] == ch[j]){
                num[j]++;
                break;
            }
        }
    }
    for(int i=0;i<ch.length();i++){
        if(num[i]!=0){
            cout << ch[i] << " -> " << num[i] << endl;
        }
    }
    return 0;
}