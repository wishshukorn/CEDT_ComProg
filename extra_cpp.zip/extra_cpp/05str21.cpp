#include<iostream>
using namespace std;
int main(){
    string a;
    cin >> a;
    int i = 0;
    while(a[i]!='\0'){
        if((((a[i]>='A'&&a[i]<='Z')||(a[i]>=48&&a[i]<=57))&&i>1)||
        (a[i-1]>=44&&a[i-1]<=57&&a[i]<44&&a[i]>57)){
            cout << ", ";
        }
        cout << a[i];
        i++;
    }
    return 0;
}