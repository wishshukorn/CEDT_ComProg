#include<iostream>
#include<string>
using namespace std;
int main(){
    string a;
    cin >> a;
    int sum=0;
    for(int i=0;i<12;i++){
        cout << a[i];
        if(i==0||i==4||i==9||i==11){
            cout << "-";
        }
        // cout << a[i];
        sum = sum+((a[i]-48)*(13-i));
    }
    cout << ((11-(sum%11))%10);
    return 0;
}