#include<iostream>
#include<vector>
#include<set>
using namespace std;
// int cnt = 0;

set<string> s;

void combi_kn(int n, vector<int> &sol,int len, int k, int chosen){
    if(len<n){
        sol[len] = 0;
        combi_kn(n, sol, len+1, k, chosen);
        if(chosen<k){
            sol[len] = 1;
            combi_kn(n, sol, len+1, k, chosen+1);
        }
    }else{
        for(int i=0;i<n;i++){
            if(sol[i]==1){
                cout << i+1 << " ";
            }
        }
        cout << endl;
    }
}

void combi(int a, int b, string ss, int len, int cnt){
    
    if(len<b&&cnt<=a){
        // v.push_back(0);
        // v[len] = 0;
        combi(a, b, ss+"0", len+1, cnt);
        // v.push_back(1);
        // v[len] = 1;
        combi(a, b, ss+"1", len+1, cnt+1);
    }else if(cnt>=a&&len==b){
        // for(int i=0;i<b;i++){
        //     cout << v[i];
        // }
        // cout << endl;
        s.insert(ss);
    }else if(cnt>=a){
        ss+="1";
        s.insert(ss);
    }
    
}
int main(){
    int a, b;
    cin >> b >> a;
    vector<int> v;
    string ss;
    combi(a, b, "", 0, 0);
    for(auto i:s){
        cout << i << endl;
    }

    // for(auto i:s){
    //     for(int j=0;j<a;j++){
    //         cout << j;
    //     }
    //     cout << endl;
    // }
}