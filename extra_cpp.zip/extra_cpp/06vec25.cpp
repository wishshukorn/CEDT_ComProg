#include<iostream>
#include<vector>
#include<tuple>
using namespace std;
int main(){
    vector<pair<string, string>> a;
    string grade[9] = {"F", "D", "D+", "C", "C+", "B", "B+", "A", "A+"};
    while(1){
        string x, y;
        cin >> x;
        if(x=="q"){
            break;
        }
        cin >> y;
        a.push_back(make_pair(x, y));
    }
    string n;
    while(cin >> n){
        for(int i=0;i<=a.size();i++){
            if(a[i].first==n){
                for(int j=0;j<9;j++){
                    if(a[i].second=="A"){
                        break;
                    }
                    if(a[i].second==grade[j]){
                        a[i].second = grade[j+1];
                        break;
                    }
                }
            }
        }
    }
    for(int i=0;i<a.size();i++){
        cout << a[i].first << " " << a[i].second << endl;
    }
    return 0;
    
}