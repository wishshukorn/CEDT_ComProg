#include<iostream>

class ccc{
    public:
    int a, b;
    void inspect() const{
        if(a<b) std::cout << "yes" << std::endl;
    }
    void mutate(){
        if(a<b) a+=10;
    }
};

void test2(ccc& changeable, const ccc& unchangeable){
    changeable.inspect();
    changeable.mutate();
    unchangeable.inspect();
    // unchangeable.mutate();
}