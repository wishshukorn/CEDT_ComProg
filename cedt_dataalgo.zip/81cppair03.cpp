#include<iostream>
#include<set>

namespace CP{
    template<typename T1, typename T2>
    class pair{
        public:
        T1 first;
        T2 second;
        bool operator == (const pair <T1, T2> &other){
            return (first == other.first && second == other.second);
        }
        // this -> first
        bool operator<(const pair <T1, T2> &other) const{
            return ((first < other.first)||(first == other.first && second < other.second));
        }
        // set, map, priority queue
    };
}

void test(int &x, const int& y){
    x++;
    std::cout << y << std::endl;
    for(int i=0;i<y;i++){
        std::cout << i << std::endl;
    }
    // y--;
}

int main(){
    CP::pair<int, std::string> p1, p2;
    p1.first = 20;
    p1.second = "somchai";
    CP::pair<int, std::string> a(p1);
    p2 = p1;
    std::cout << p2.first << ", " << p2.second << std::endl;
    if(p1 == p2) {  // p1.operator==(p2)
        std::cout << "yes" << std::endl;
    }
    if(p1 < a){
        std::cout << "no" << std::endl;
    }
    std::set<CP::pair<int, int>> s;
    s.insert({1, 2});
    std::cout << s.begin() -> second << std::endl;
}