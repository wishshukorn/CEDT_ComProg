#include<iostream>
using namespace std;
int main(){
    int cnt = 0;
    string s = "The Necessity of Training Farm Hands for First Class Farms in the Fatherly Handling of Farm Live Stock is Foremost in the Eyes of Farm Owners. Since the Forefathers of the Farm Owners Trained the Farm Hands for First Class Farms in the Fatherly Handling of Farm Live Stock, the Farm Owners Feel they should carry on with the Family Tradition of Training Farm Hands of First Class Farmers in the Fatherly Handling of Farm Live Stock Because they Believe it is the Basis of Good Fundamental Farm Management.";
    for(int i=0;i<s.length();i++){
        if(s[i]=='f'||s[i]=='F'){
            cnt++;
        }
    }
    cout << cnt;
    return 0;
}