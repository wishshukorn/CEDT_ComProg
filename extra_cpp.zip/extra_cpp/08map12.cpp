// not finish

#include<iostream>
#include<map>
using namespace std;
int main(){
    int n;
    string a, b;
    map<string, string> m1;
    cin >> n;
    while(n--){
        cin >> a >> b;
        m1[a] = b;
    }
    cin >> n;
    while(n--){
        cin >> a;
        if(m1.find(a)!=m1.end()){
            cout << a << " --> " << m1[a] << endl;
        }else{
            for(auto& it:m1){
                if(it.second==a){
                    cout << a << " --> " << it.first << endl;
                    break;
                }
            }
        }
    }
}