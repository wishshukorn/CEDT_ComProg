#include<iostream>
#include<vector>
using namespace std;

void recurmat(vector<vector<int>>& v, int a, int b, int top, int left, int bottom, int right){
    if(a==0){
        v[top][left] = b;
        return;
    }
    int midy = (top + bottom) / 2;
    int midx = (left + right) / 2;
    recurmat(v, a-1, b, top, left, midy, midx);
    recurmat(v, a-1, b-1, top, midx, midy, right);
    recurmat(v, a-1, b+1, midy, left, bottom, midx);
    recurmat(v, a-1, b, midy, midx, bottom, right);
}

int main(){
    int a, b;
    cin >> a >> b;
    int sizee = 1<<a;
    vector<vector<int>> v(sizee, vector<int>(sizee));
    recurmat(v, a, b, 0, 0, sizee, sizee);
    for(int i=0;i<sizee;i++){
        for(int j=0;j<sizee;j++){
            cout << v[i][j] << " ";
        }
        cout << endl;
    }
}