#include<iostream>
#include<map>
using namespace std;


int n;


void perm(string s, int len, bool chk[], map<int, int> tor){
    if(len==n){
        cout << s << "\n";
        return;
    }
    
    for(int i=0;i<n;i++){
        if(chk[i] == false && (!tor.count(i) || chk[tor.at(i)])){
            chk[i] = true;
            perm(s + to_string(i) + " ", len+1, chk, tor);
            chk[i] = false;
        }
    }
    
        
    
}

int main(){
    ios::sync_with_stdio(false); cin.tie(NULL);
    int m;
    int a, b;

    cin >> n >> m;
    
    map<int, int> tor;
    bool chk[n] = {false};
    string s = "";
    
    
    for(int i=0;i<m;i++){
        cin >> a >> b;
        tor[b] = a;
    }
    perm("",0,chk,tor);
}