#include<iostream>
using namespace std;
int main(){
    int d, m, y, ans=0;
    cin >> d >> m >> y;
    y = y-543;
    for(int i=1;i<m;i++){
        if(i==2&&y%4==0&&(y%100!=0||y%400==0)){
            ans = ans - 2;
        }
        else if(i==2){
            ans = ans - 3;
        }
        if(i==4||i==6||i==9||i==11){
            ans = ans - 1;
        }
        ans = ans + 31;
    }
    ans = ans + d;
    cout << ans;
    return 0;
}