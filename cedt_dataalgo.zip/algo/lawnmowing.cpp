#include<iostream>
#include<vector>
using namespace std;

int main(){
    int n, m, k;

    cin >> n >> m >> k;

    vector<int> a(n, 0);
    int b;
    int l, r;

    for(int i=0;i<n;i++){
        cin >> a[i];
    }

    for(int i=0;i<m;i++){
        vector<int> aa = a;
        cin >> l >> b;

        int j = l+1;
        aa[j] = aa[j] + aa[j-1];

        // r = l+1;
        int mon = 0;
        // int sum = 0;
        
        while(mon<=b){
            j++;
            aa[j] = aa[j] + aa[j-1];
            mon = aa[j] + (j-l) * k;
        }
        cout << aa[j] << endl;


    }
}