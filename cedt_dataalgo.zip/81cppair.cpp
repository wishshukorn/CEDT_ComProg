#include<iostream>

namespace CP{
    template <typename T1, typename T2>
    class pair{
        public:
        T1 first;
        T2 second;
    };
}

int main(){
    CP::pair<int, std::string> p1;
    CP::pair<bool, int> p2;
}