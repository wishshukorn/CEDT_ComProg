#include<iostream>
#include<map>
using namespace std;
// int main(){
//     map<string, int> m;
//     m["somchai"] = 10;
//     m["somying"] = -5;
//     cout << "Size = " << m.size() << endl;
//     cout << "m[\"xxx\"] = " << m["xxx"] << endl;
//     for(auto it = m.begin(); it!=m.end(); it++){
//         cout << it -> first << " is mapped to " << it -> second << endl;
//     }
//     m["abc"]++;
//     cout << "Now size = " << m.size() << endl;
//     for(auto &x : m){
//         cout << x.first << " is mapped to " << x.second << endl;
//     }
// }

int main(){
    map<int, string> m;
    m[1] = "somchai";
    m[99] = "nattee";
    int k = 99;
    map<int, string>::iterator it;
    if((it = m.find(k)) != m.end()){
        cout << "Key " << it -> first << " is mapped to " << it -> second << endl;
    }else{
        cout << "Key " << k << " is not exists in m." << endl;
    }
    
    // Don't use it
    if(m[k]!=""){
        cout << "exits" << endl;
    }else{
        cout << "does not exits" << endl;
    }
}