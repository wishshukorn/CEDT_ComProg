#include<iostream>
using namespace std;
int main(){
    long long a;
    cin >> a;
    int i=2;
    while(a!=1){
        while(a%i==0){
            cout << i;
            a = a/i;
            if(a!=1){
                cout << '*';
            }
        }
        i++;
    }
    return 0;
}