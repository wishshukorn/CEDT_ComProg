#include<iostream>
using namespace std;

string s19[] = {"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", 
    "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"};
string tens[] = {"", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"}; 
string huns[] = {"", "thousand", "million", "billion", "trillion"};

string convert3(string a){
    
    a = a.substr(a.length()-3);
    int d1 = a[2] - '0', d10 = a[1] - '0', d100 = a[0] - '0';
    int d2 = d10*10 + d1;
    string x;
    /*
    if(d2 < 20){
        x = s19[d2];
    }else{
        x = tens[d10] + ' ' + s19[d1];
    }
    */
    x = (d2 < 20) ? s19[d2] : tens[d10] + ' ' + s19[d1];
    
    if(d100 != 0){
        x = s19[d100] + " hundred " + x;
    }

    return x;
}

int main(){
    string a;
    std::cin >> a;
    a = string((3-a.length()%3)%3, '0') + a;
    string o;
    for(int i=a.length()-3, k=0; i>=0; i=i-3, k++){
        string x = convert3(a.substr(i, 3));
        if(x != ""){
            o = x + " " + huns[k] + " " + o;
        }
    }
    if(o == ""){
        o = "zero";
    }
    cout << o;
    
    return 0;
}