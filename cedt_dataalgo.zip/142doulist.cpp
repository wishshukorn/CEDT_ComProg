node *p = mFirst;
while(p!=NULL && p->next != x){
    p = p->next;
}

// doubly linked list
// insert
node<int> *tmp = new node<int> (99, NULL, NULL);
tmp->next = x;
tmp->prev = x.prev;
x->prev->next = tmp;
x->prev = tmp;

//erase
x->prev->next = x->next;
x->next->prev = x->prev;
delete x;

class node{
    public:
    ValueT data;
    node *left, *right;
    node():
        data(ValueT()), left(NULL), right(NULL) {}
    node(const ValueT& data, node* left, node* right):
        data(data), left(left), right(right) {}
}