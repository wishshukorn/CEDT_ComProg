#include<iostream>
using namespace std;
int main(){
    int n;
    cin >> n;
    string a[n], c[1000];
    int b[n];
    string ss;
    int kk = 0, ans=0;
    for(int i=0;i<n;i++){
        cin >> a[i] >> b[i];
        // cout << a[i] << ", " << b[i] << "\n";
    }
    // cin.ignore();
    // getline(cin, ss);
    // int ci = ss.length()/6;
    // cout << ci;
    while(cin >> ss){
        c[kk] = ss.substr(4,2);
        // cout << "UK" << a[2] << "\n";
        // c[kk] = c[kk] + ss[5];
        kk++;
        // la = kk;
    }
    // for(int i=0;i<kk;i++){
    //     cout << c[i] << endl;
    // }
    // cout << kk;
    for(int i=1;i<kk;i++){
        // cout << "Hello";
        if(c[i]!=c[i-1]){
            // cout << c[i];
            for(int j=0;j<n;j++){
                if(c[i]==a[j]){
                    // cout << "Y";
                    ans = ans + b[j];
                    break;
                }
            }
            
        }
    }
    cout << ans << endl;
    // cout << a[2];
    return 0;
}