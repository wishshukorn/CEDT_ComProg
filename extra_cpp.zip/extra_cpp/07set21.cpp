#include<iostream>
#include<set>
using namespace std;
int main(){
    int n;
    cin >> n;
    set<int> s;
    int a;
    while(cin >> a){
        s.insert(a);
    }
    // int nset = s.size();
    auto itr = s.begin();
    // auto itl = s.end();
    // while(itr != s.end()){
    //     itr++;
    // }
    int cnt=0;
    // set<int> ss;
    while(itr!=s.end()){
        auto itl = s.end();
        // itl--;
        if(*itr>n){
            break;
        }
        int sub = n-*itr;
        // ss.insert(sub);
        // if(sub == *itl){
        //     cout << *itr << " + " << sub << " = " << n << endl;
        //     cnt++;
        // }
        if(s.find(sub)!=s.end()){
            // cout << *itr << " + " << sub << " = " << n << endl;
            cnt++;
        }
        // while(itl!=s.begin()){
        //     if(sub==*itl){
        //         cout << *itr << " + " << sub << " = " << n << endl;
        //         cnt++;
        //     }
        //     itl--;
        // }
        // itl--;
        itr++;
    }
    cout << (cnt/2);
    return 0;
}