#include<iostream>
using namespace std;
int main(){
    string a, b;
    int cnt=0;
    getline(cin, a);
    getline(cin, b);
    // cout << a.length() << endl << b.length() << endl;
    if(a.length()!=b.length()){
        cout << "Incomplete answer";
        return 0;
    }
    for(int i=0;i<a.length();i++){
        if(a[i]==b[i]){
            cnt++;
        }
    }
    cout << cnt;
    return 0;
}