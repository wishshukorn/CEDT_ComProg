#include<iostream>
#include<string>
using namespace std;
int main(){
    int n, k, b;
    string s(21, '0');
    cin >> n >> k;
    b = 1 << n;
    k = (1 << k) - 1;
    for(int i=0;i<b;i++){
        int ans = 0;
        for(int j=i;j>=k;j = j >> 1){
            ans |= (j&k) == k;
        }
        if(!ans){
            continue;
        }
        for(int j=n, p=i;j--; p = p >> 1){
            s[j] = '0' ^ (p&1);
        }
        cout << s.substr(0,n) << endl;
    }
    // cout << b << k;
    return 0;
}

// #include <iostream>
// #include <string>
// using namespace std;

// int N, K, B;
// string S(25, '0');  // Initialize string S with 25 '0' characters

// int main() {
//     cin >> N >> K;  // Using C++ style input

//     B = 1 << N;  // Bitwise left shift, same as in C
//     K = (1 << K) - 1;  // Bitwise left shift to get K's mask

//     // Loop through all values from 0 to B-1 (2^N)
//     for (int i = 0; i < B; i++) {
//         int Ans = 0;

//         // Inner loop to check if the combination is valid
//         for (int j = i; j >= K; j >>= 1)
//             Ans |= (j & K) == K;

//         // If no valid combination, continue with the next iteration
//         if (!Ans) continue;

//         // Construct the binary string
//         for (int j = N, k = i; j--; k >>= 1)
//             S[j] = '0' ^ (k & 1);  // Convert bit to character '0' or '1'

//         // Output the binary string
//         cout << S.substr(0, N) << endl;  // Print only the first N characters of S
//     }

//     return 0;
// }
