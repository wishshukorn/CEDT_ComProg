#include<iostream>
#include<set>
using namespace std;
int main(){
    set<long long> a;
    long long n;
    while(cin >> n){
        a.insert(n);
    }

    cout << a.size() << endl;
    int j=0;
    for(auto i=a.begin();i!=a.end(); i++){
        if(j==10){
            break;
        }
        cout << *i << " ";
        j++;
    }
    return 0;
}