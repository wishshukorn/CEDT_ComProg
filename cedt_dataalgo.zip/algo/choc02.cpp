#include<iostream>
using namespace std;
int main(){
    long long n, k;
    cin >> n >> k;
    long long sum[n+1]={0}, a[k];
    sum[0] = 1;
    for(int i=0;i<k;i++){
        cin >> a[i];
    }
    for(long long i=0;i<n;i++){
        for(long long j=0;j<k;j++){
            if(i + a[j] <= n){
                sum[i+a[j]] = (sum[i] + sum[i + a[j]]) % 1000003;
            }
        }
    }
    cout << sum[n];
}