#ifndef __STUDENT_H_
#define __STUDENT_H_

#include <algorithm>
#include <iostream>

template <typename T>
void CP::queue<T>::move_to_front(size_t pos) {
    //your code here
    for(size_t i=mFront+pos;i>mFront;i--){
        std::swap(mData[(i)%mCap],mData[(i-1)%mCap]);
    }
}

#endif

// template<typename T>
// void CP::queue<T>::move_to_front(size_t p){
//     for(size_t i=mFront+p;i>mFront;i--){
//         std::swap(mData[(i)%mCap],mData[(i-1)%mCap]);}}

