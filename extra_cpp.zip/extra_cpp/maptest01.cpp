#include<iostream>
#include<map>
#include<vector>
using namespace std;

void printt(map<string, double> m){
    for(auto i=m.begin();i!=m.end();i++){
        cout << (*i).first << " " << (*i).second << endl;
    }
}

void tsort(vector<int> & v){
    map<int, int> m;
    for(auto e : v){
        auto it = m.find(e);
        if(it == m.end()){
            m[e] = 1;
        }else{
            ++m[e]; // ++((*it).second)
        }
    }
    v.clear();
    for(auto & kv : m){
        while(kv.second--){
            v.push_back(kv.first);
        }
    }
}

int main(){
    map<string, double> stock_index = {{"SET", 1534.81}, {"Hang Seng", 18949.94}, {"Nikkei", 31524.22}};
    map<string, double> m1(stock_index);
    auto m2(stock_index);

    map<int, int> m3 = {{1, 2}, {4, 5}, {9, 6}};
    map<int, int> m4 = {{9, 6}, {1, 2}, {4, 5}};
    cout << (m3 == m4) << endl;
    map<int, int> m5 = {{9, 0}, {1, 2}, {4, 5}};
    cout << (m4 == m5) << endl;

    map<string, double> stockk;
    stockk["SET"] = 1534.81;
    stockk["Gang Seng"] = 18949.94;
    stockk["Nikkei"] = 31524.22;
    printt(stockk);
    cout << endl;
    stockk["SET"] = 1530.23;
    printt(stockk);
    cout << endl;

    map<int, int> m6 = {{9, 11}, {3, 13}, {1, 12}};
    auto itr = m6.begin();
    cout << (*(++itr)).second << endl; // key 2nd max

    for(auto itr = m6.begin(), end = m6.end(); itr != end; itr++){
        auto & kv = *itr;
        cout << kv.first << " " << kv.second << endl;
    }

    for(auto & kv : m6){
        cout << kv.first << " " << kv.second << endl;
    }

    for(auto itr = m6.end();itr!=m6.begin();){
        auto & kv = *(--itr);
        cout << kv.first << " : " << kv.second << endl;
    }

    cout << (m6.find(1) != m6.end()) << endl;
    cout << (m6.find(2) != m6.end()) << endl;

    map<int, string> m7;
    int key;
    auto ii = m7.find(key);
    cout << (ii != m7.end() ? (*ii).second : "?\n");

    // tsort(vector)
    // number : frequence

    map<int, int> m8= {{9, 11}, {1, 12}, {3, 13}};
    auto itrr = m8.begin();
    ++itrr;
    itrr = m8.erase(itrr);
    cout << (*itrr).first << endl;
    for(auto & kv : m8){
        cout << kv.first << " = " << kv.second << endl;
    }
    map<int, int> m9= {{9, 11}, {1, 12}, {3, 13}};
    int r;
    r = m9.erase(3);
    cout << r << endl;
    r = m9.erase(99);
    cout << r << endl;
    for(auto & kv : m9){
        cout << kv.first << " : " << kv.second << endl;
    }

    // map<int, string> m10 = {{4, "four"}};

    map<string, int> votes = {{"Jisoo", 0}, {"Jennie", 0}, {"Rose", 0}, {"Lisa", 0}};
    
    // for(string name; cin >> name;){
    //     if(votes.find(name)!=votes.end()){
    //         ++votes[name];
    //     }
    // }
    for(string name; cin >> name;){
        auto itr = votes.find(name);
        if(itr != votes.end()){
            ++((*itr).second);
        }
    }
    for(auto & kv : votes){
        cout << kv.first << " --> " << kv.second << endl; 
    }

    map<string, int> votes2;
    for(string name; cin >> name;){
        auto itr = votes.find(name);
        if(itr!=votes2.end()){
            votes[name]++;
        }else{
            votes[name] = 1;
        }
    }

    for(auto & kv : votes2){
        cout << kv.first << " --> " << kv.second << endl; 
    }

    map<string, string> country;
    map<string, int> fee;
    int n, f, total = 0;
    string air, ct, last;
    
    cin >> n;
    while(n--){
        cin >> air >> ct;
        country[air] = ct;
    }

    cin >> n;
    while(n--){
        cin >> ct >> f;
        fee[ct] = f;
    }
    
    while(cin >> air){
        if(country[air] != country[last]){
            total += fee[country[air]];
        }
        last = air;
    }
    cout << total;



    return 0;
}