#include<iostream>
#include<map>
#include<queue>
using namespace std;

void showSolution(int v, map<int, int>& prev){
    string out = "";
    while(prev[v] != -1){
        if(prev[v]*3 == v){
            out = "x3" + out; 
        }else{
            out = "/2" + out;
        }
        v = prev[v];
    }
    out = "1" + out;
    cout << out << endl;
}

void m3d2(int target){
    map<int, int> prev;
    queue<int> q;
    int v = 1;
    q.push(1);
    prev[1] = -1;
    while(!q.empty()){
        v = q.front();
        q.pop();
        if(v == target){
            break;
        }
        int v2 = v/2;
        int v3 = v*3;
        if(prev[v2] == 0){ // never appear
            q.push(v2);
            prev[v2] = v;
        }
        if(prev[v3] == 0){
            q.push(v3);
            prev[v3] = v;
        }
    }
    if(v == target){
        showSolution(v, prev);
    }
}

int main(){
    m3d2(10);
}