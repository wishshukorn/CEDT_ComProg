#include<iostream>
#include<string>
using namespace std;
int main(){
    int n;
    cin >> n;
    cin.ignore();
    string a;

    for(int i=0;i<n;i++){
        bool check1=true, check2=true;
        getline(cin, a);
        if(a[0]!='R'){
            check1 = false;
        }
        for(int j=0;j<a.length();j=j+4){
            
            if(a[j]=='R'&&a[j+2]=='R'){
                check2 = false;
                break;
            }
            else if(!(a[j]=='R'||a[j]=='Y')){
                check2 = false;
                break;
            }else if(a[j]=='Y'){
                string ss = a.substr(j, (a.length()-j));
                // cout << ss;
                if(ss=="Y"||ss=="Y G"||ss=="Y G N"||ss=="Y G N B"||ss=="Y G N B P"||ss=="Y G N B P K"){
                    break;
                }else{
                    check2=false;
                    break;
                }
                // for(int k=j;k<a.length();k = k+2){
                //     // int m;
                // }
                // if(a[j+2]=='G'||a[j+2]==NULL){}
            }
            // cout << a[j] << endl;
            
        }
        if(check1&&check2){
            string strans = "RYGNBPK";
            int inans[] = {1, 2, 3, 4, 5, 6, 7};
            int sum=0;
            for(int j=0;j<a.length();j=j+2){
                for(int k=0;k<7;k++){
                    if(a[j] == strans[k]){
                        sum = sum + inans[k];
                    }
                }
            }
            cout << sum << endl;
        }else{
            cout << "WRONG_INPUT" << endl;
        }

    }
    // for(int i=0;i<=n;i++){
    //     cout << a[i] << endl;
    // }
    // for(int i=0;i<=n;i++){
    //     for(int j=0;j<a[i].length();j++){
    //         if(a[i][j]!=' '){
    //             if(a[i][j]!="R"&&j==0){
    //                 check = false;
    //             }
    //             else if(a[j]=="R"){

    //             }
    //         }
    //     }
    // }
    // for(int i=0;i<n;i++){
    //     for(int j=0;a[i][j]!='R';j=j+4){ //R U R
    //         cout << a[i][j] << endl;
    //     }
    // }
    
}