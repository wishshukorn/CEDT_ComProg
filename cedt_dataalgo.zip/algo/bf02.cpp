#include<iostream>
#include<vector>
#include<queue>
using namespace std;

// struct Node{
//     int airport, cost;
//     bool operator>(const Node& other) const{
//         return cost > other.cost;
//     }
// }


int main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int n, m;
    cin >> n >> m;
    vector<int> ci(n), co(n);
    for(int i=0;i<n;i++){
        cin >> ci[i];
    }
    for(int i=0;i<n;i++){
        cin >> co[i];
    }
    vector<vector<int>> adj(n);
    for(int i=0;i<m;i++){
        int a, b;
        cin >> a >> b;
        adj[a].push_back(b);
    }
    vector<int> dist(n, INT_MAX);
    dist[0] = 0;

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0, 0});
    while(!pq.empty()){
        int u = pq.top().second;
        int cost = pq.top().first;
        pq.pop();
        if(cost > dist[u]){
            continue;
        }
        for(int v:adj[u]){
            int new_cost = dist[u] + co[u] + ci[v];
            if(new_cost < dist[v]){
                dist[v] = new_cost;
                pq.push({new_cost, v});
            }
        }
    }
    for(int i=0;i<n;i++){
        if(dist[i]==INT_MAX){
            cout << -1 << " ";
        }else{
            cout << dist[i] << " ";
        }
    }
    cout << "\n";
    
}