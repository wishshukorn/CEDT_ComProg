#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int main(){
    int n, m, k;
    cin >> n >> m >> k;
    vector<int> a(n+1, 0);
    for(int i=1;i<=n;i++){
        cin >> a[i];
        a[i] = a[i] + a[i-1] + k;
    }
    cout << endl;
    int l, b;
    for(int i=0;i<m;i++){
        cin >> l >> b;
        auto itr = (upper_bound(a.begin(), a.end(), b+a[l]));
        if(itr == a.begin() +1){
            cout << 0 << endl;
            continue;
        }
        itr--;
        cout << (*itr - a[l] -((itr-a.begin()-l)*k)) << "\n";

    }
}