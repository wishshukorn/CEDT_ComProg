#include<iostream>
using namespace std;
int main(){
    string a;
    string sum = 0;
    int tod = 0;
    while(cin >> a){
        if(a == "END"){
            break;
        }
        for(int i=a.length()-1, j=sum.length(); i>=0&&j>=0; i++, j++){
            int num = a[i] - '0';
            int sumnum = sum[j] - '0';
            cout << num << " " << sumnum << endl;
        }
        return 0;
        
    }
}