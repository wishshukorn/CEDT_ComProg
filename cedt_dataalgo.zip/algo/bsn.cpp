#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int main(){
    int n, m;
    cin >> n >> m;
    vector<int> a(n), b(m);
    for(int i=0;i<n;i++){
        cin >> a[i];
    }
    for(int i=0;i<m;i++){
        cin >> b[i];
        auto itr = upper_bound(a.begin(), a.end(), b[i]);
        if(itr == a.begin() && b[i] != a[0]){
            cout << -1 << endl;
            continue;
        }
        itr--;
        cout << *itr << endl;
    }

}