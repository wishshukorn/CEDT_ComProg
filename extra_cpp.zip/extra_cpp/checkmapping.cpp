#include<iostream>
#include<set>
using namespace std;
int main(){
    int n, b;
    set<int> a;
    cin >> n;
    for(int i=0;i<n;i++){
        cin >> b;
        a.insert(b);
    }
    if(a.size()!=n||*a.begin()<1||*(--a.end())>n){
        cout << "NO";
    }else{
        cout << "YES";
    }
    return 0;
}