#include<iostream>
using namespace std;
int main(){
    int n, cnt=0, last;
    cin >> n;
    int a[n], maxx = 0, b[n], c[n];
    for(int i=0;i<n;i++){
        cin >> a[i];
        maxx = max(maxx, a[i]);
    }
    for(int i=0;i<n;i++){
        while(a[i]==1){
            for(int j=0;j<maxx;j++){
                b[j] = a[i+j];
                c[j] = a[i-j];
            }
            for(int j=0;j<maxx;j++){
                // for()
            }
            last = a[i];
            cnt++;
            for(int j=0;j<n;j++){
                if(a[i+j]==last+1||a[i-j]==last+1){}
            }
        }
    }
    // for(int i=0;i<n;i++){
    //     for(int j=0;j<n;j++){

    //     }
    // }
}