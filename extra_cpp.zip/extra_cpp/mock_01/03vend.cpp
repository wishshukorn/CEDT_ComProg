#include<iostream>
#include<string>
using namespace std;
int main(){
    long n;
    cin >> n;
    string a;
    long b, sum=0;
    while(cin>>a){
        long len = a.length();
        for(long i=1;i<len;i++){
            a[i-1] = a[i];
        }
        a[len-1] = '\0';
        // cout << stoi(a) << endl;
        b = stoi(a);
        sum = sum+b;
    }
    cout << (sum*n);
}