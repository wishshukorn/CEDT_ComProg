// void fixDown(size_t idx) {
//     T tmp = mData[idx];
//     size_t c;
//     while ((c = 2 * idx + 1) < mSize) {
//     if (c + 1 < mSize && mLess(mData[c],mData[c + 1]) ) c++;
//     if ( mLess(mData[c],tmp) ) break;
//     mData[idx] = mData[c];
//     idx = c;
//     }
//     mData[idx] = tmp;
// }

#include<iostream>
#include<vector>
using namespace std;
int main(){
    int n, a, cnt = 0;
    cin >> n >> a;
    vector<int> v;
    v.push_back(a);
    for(int i=0;i<v.size();i++){
        
        int c1 = (2*v[i])+1;
        int c2 = (2*v[i])+2;
        if(c1>n-1){
            break;
        }
        if(c2>n-1){
            v.push_back(c1);
            cnt++;
            break;
        }
        v.push_back(c1);
        v.push_back(c2);
        cnt = cnt + 2;

    }
    cout << cnt+1 << endl;
    for(int i=0;i<v.size();i++){
        cout << v[i] << " ";
    }
    
}