#include<iostream>
using namespace std;
int main(){
    string a;
    while(getline(cin, a)){
        string b="";
        int i=0;
        while(a[i]!='\0'){
            if(((a[i]>=33&&a[i]<=47)||(a[i]>=58&&a[i]<=64)||(a[i]>=91&&a[i]<=96)||(a[i]>=123&&a[i]<=126))&&a[i+1]!='\0'){
                char pap = a[i];
                i++;
            // while(((a[i]>=33&&a[i]<=47)||(a[i]>=58&&a[i]<=64)||(a[i]>=91&&a[i]<=96)||(a[i]>=123&&a[i]<=126))){
            //     i++;
            // }
            //(a[i]>=33&&a[i]<=47)||(a[i]>=58&&a[i]<=64)||(a[i]>=91&&a[i]<=96)||(a[i]>=123&&a[i]<=126)
            while(a[i]!=pap&&a[i+1]!='\0'){
                b = b + a[i];
                i++;
            }
            // i++;
        }
        i++;
    }
    cout << b << endl;
    }
    
}