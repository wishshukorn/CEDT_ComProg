#include<iostream>
using namespace std;
int main(){
    int n;
    cin >> n;
    int a[n][4], area[n][n]={{0,0}}, mx = 0;
    for(int i=0;i<n;i++){
        for(int j=0;j<4;j++){
            cin >> a[i][j];
        }
    }
    // int k=0;
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            int l = max(a[i][0], a[j][0]);
            int r = min(a[i][2], a[j][2]);
            int t = min(a[i][3], a[j][3]);
            int b = max(a[i][1], a[j][1]);
            area[i][j] = (r-l)*(t-b);
            // cout << "area of " << i << " and " << j << " = " << area[i][j] << endl;
            if(l>=r||t<=b){
                area[i][j] = 0;
                // k++;
                continue;
            }
            if(area[i][j]>mx){
                mx = area[i][j];
            }
            // k++;
            
        }
    }
    // cout << endl << mx << endl << endl;
    // k=0;
    if(mx==0){
        cout << "No overlaps" << endl;
        return 0;
    }
    cout << "Max overlapping area = " << mx << endl;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(area[i][j]==mx){
                cout << "rectangles " << i << " and " << j << endl;
            }
            // k++;
        }
    }
    // cout << endl;
    // for(int i=0;i<k;i++){
    //     cout << area[i] << endl;
    // }
    return 0;
}