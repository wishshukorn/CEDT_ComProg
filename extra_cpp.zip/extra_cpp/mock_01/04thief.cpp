#include<iostream>
using namespace std;
int main(){
    int n, m, sum = 0;
    cin >> n >> m;
    int a[n];
    for(int i=0;i<n;i++){
        cin >> a[i];
        sum = sum + a[i];
    }
    sum = sum - m;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(a[i]+a[j]==sum){
                cout << i << " " << a[i] << endl << j << " " << a[j];
                return 0;
            }
        }
    }
}