#include<iostream>
using namespace std;
int main(){
    int n;
    cin >> n;
    int a[n*n];
    int ze, cnt = 0;
    for(int i=0;i<n*n;i++){
        cin >> a[i];
        if(a[i]==0){
            ze = i;
        }
    }
    ze = ze/n;
    for(int i=0;i<n*n;i++){
        if(a[i] == 0){
            continue;
        }
        for(int j=i;j<n*n;j++){
            if(a[j] == 0){
                continue;
            }
            if(a[i] > a[j]){
                cnt++;
            }
        }
    }
    // cout << cnt << endl << ze << endl;
    if((n%2==1 && cnt%2==0)||(n%2==0 && cnt%2==1 && ze%2==0)||(n%2==0 && cnt%2==0 && ze%2==1)){
        cout << "YES";
    }else{
        cout << "NO";
    }
    return 0;
}