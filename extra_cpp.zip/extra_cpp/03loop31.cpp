#include<iostream>
// #include<cmath>
using namespace std;

long long Pow(long long a, long long b){
    long long sum=1;
    for(long long i=0;i<b;i++){
        sum = sum*a;
    }
    return sum;
}

long long Sum(long long n){
    long long ans=1, a=1;
    while(n >= Pow(10, a)){
        ans = ans + (a*9*(Pow(10, a-1)));
        a++;
    }
    ans = ans + a*((n - (Pow(10, a-1))) + 1);
    return ans;
}

int main(){
    long long m, n;
    cin >> m >> n;
    // cout << Pow(10, 2) << endl;
    cout << (Sum(n)-Sum(m-1));
}