#include<iostream>
#include<vector>
using namespace std;
// int cnt = 0;
void combi(int a, int b, int v[], int len, int cnt){
    if(len<b&&cnt<=a){
        v[len] = 0;
        combi(a, b, v, len+1, cnt);
        v[len] = 1;
        combi(a, b, v, len+1, cnt+1);
    }else if(cnt==a){
        for(int i=0;i<b;i++){
            cout << v[i];
        }
        cout << endl;
    }
}
int main(){
    int a, b;
    cin >> a >> b;
    int v[b] = {0};
    combi(a, b, v, 0, 0);
}